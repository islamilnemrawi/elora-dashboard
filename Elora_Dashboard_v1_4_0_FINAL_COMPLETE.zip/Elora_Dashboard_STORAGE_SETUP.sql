-- Elora: simple image upload storage
-- Run once in Supabase SQL Editor.

insert into storage.buckets (id, name, public)
values ('elora-images', 'elora-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Elora staff can upload images" on storage.objects;
create policy "Elora staff can upload images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'elora-images'
  and (
    public.has_staff_permission('products.add')
    or public.has_staff_permission('products.edit')
    or public.has_staff_permission('categories.manage')
    or public.has_staff_permission('offers.manage')
    or public.has_staff_permission('site.hero')
    or public.has_staff_permission('settings.manage')
  )
);

drop policy if exists "Elora staff can update images" on storage.objects;
create policy "Elora staff can update images"
on storage.objects for update to authenticated
using (
  bucket_id = 'elora-images'
  and (
    public.has_staff_permission('products.edit')
    or public.has_staff_permission('categories.manage')
    or public.has_staff_permission('offers.manage')
    or public.has_staff_permission('site.hero')
    or public.has_staff_permission('settings.manage')
  )
)
with check (bucket_id = 'elora-images');

drop policy if exists "Elora staff can delete images" on storage.objects;
create policy "Elora staff can delete images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'elora-images'
  and (
    public.has_staff_permission('products.delete')
    or public.has_staff_permission('categories.manage')
    or public.has_staff_permission('offers.manage')
    or public.has_staff_permission('site.hero')
    or public.has_staff_permission('settings.manage')
  )
);

-- Public website can display uploaded images because the bucket is public.
