-- ELORA DASHBOARD PROFESSIONAL UPGRADE
-- Dashboard-side support for first-order-only coupons.
-- This file does NOT modify the customer-facing website.

begin;

alter table public.coupons
  add column if not exists first_order_only boolean not null default false;

create index if not exists idx_coupons_first_order_only
  on public.coupons(first_order_only, active);

-- Server-side validator for future checkout wiring.
-- Identity can be supplied by authenticated user_id and/or guest phone.
create or replace function public.validate_coupon_for_customer(
  p_code text,
  p_subtotal numeric,
  p_user_id uuid default null,
  p_customer_phone text default null
)
returns table(
  valid boolean,
  id uuid,
  code text,
  discount_type text,
  discount_value numeric,
  max_discount numeric,
  free_shipping boolean,
  first_order_only boolean,
  message text
)
language plpgsql
security definer
set search_path = public
as $$
declare
  c public.coupons%rowtype;
  has_previous_order boolean := false;
  phone_clean text := nullif(regexp_replace(coalesce(p_customer_phone,''),'[^0-9]','','g'),'');
begin
  select * into c
  from public.coupons
  where upper(code)=upper(trim(p_code))
  limit 1;

  if not found then
    return query select false,null::uuid,null::text,null::text,null::numeric,null::numeric,false,false,'كود الخصم غير صحيح';
    return;
  end if;
  if not c.active then
    return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'كود الخصم غير مفعّل';
    return;
  end if;
  if c.starts_at is not null and now() < c.starts_at then
    return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'الكود لم يبدأ بعد';
    return;
  end if;
  if c.expires_at is not null and now() > c.expires_at then
    return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'كود الخصم منتهي';
    return;
  end if;
  if c.usage_limit is not null and c.used_count >= c.usage_limit then
    return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'تم استنفاد عدد استخدامات الكود';
    return;
  end if;
  if coalesce(p_subtotal,0) < coalesce(c.min_order,0) then
    return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'قيمة الطلب أقل من الحد الأدنى للكود';
    return;
  end if;

  if c.first_order_only then
    if p_user_id is not null then
      select exists(
        select 1 from public.orders o where o.user_id=p_user_id
      ) into has_previous_order;
    elsif phone_clean is not null then
      select exists(
        select 1 from public.orders o
        where regexp_replace(coalesce(o.customer_phone,o.phone,''),'[^0-9]','','g') = phone_clean
      ) into has_previous_order;
    else
      return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'هذا الكود مخصص لأول طلب ويتطلب هوية العميل أو رقم الهاتف';
      return;
    end if;
    if has_previous_order then
      return query select false,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'هذا الكود متاح لأول طلب فقط';
      return;
    end if;
  end if;

  return query select true,c.id,c.code,c.discount_type,c.discount_value,c.max_discount,c.free_shipping,c.first_order_only,'تم تطبيق كود الخصم';
end;
$$;

revoke all on function public.validate_coupon_for_customer(text,numeric,uuid,text) from public;
grant execute on function public.validate_coupon_for_customer(text,numeric,uuid,text) to anon, authenticated;

commit;

select 'ELORA dashboard professional upgrade SQL ready' as status;
