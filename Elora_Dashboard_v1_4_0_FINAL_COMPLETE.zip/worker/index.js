const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8' };

function cors(origin) {
  const allowed = (origin && origin !== 'null') ? origin : '*';
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin'
  };
}

function response(body, status, origin) {
  return new Response(JSON.stringify(body), { status, headers: { ...JSON_HEADERS, ...cors(origin) } });
}

function permissionFor(folder) {
  if (folder === 'products') return ['products.add', 'products.edit'];
  if (folder === 'categories') return ['categories.manage', 'categories.edit'];
  if (folder === 'offers') return ['offers.manage'];
  if (folder === 'banners') return ['site.hero'];
  return ['settings.manage'];
}

async function getStaff(env, token) {
  const r = await fetch(`${env.SUPABASE_URL}/rest/v1/staff_profiles?select=id,role,permissions,active&id=eq.${encodeURIComponent(token.userId)}`, {
    headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}` }
  });
  if (!r.ok) return null;
  const rows = await r.json();
  return rows[0] || null;
}

function hasPermission(staff, permissions) {
  if (!staff?.active) return false;
  const role = String(staff.role || '').toLowerCase();
  if (['owner', 'admin', 'manager'].includes(role)) return true;
  const p = staff.permissions || {};
  return permissions.some(x => p[x] === true || p[x] === 1 || p[x] === 'true');
}

async function verifyUser(env, auth) {
  if (!auth?.startsWith('Bearer ')) return null;
  const token = auth.slice(7);
  const r = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: env.SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}` }
  });
  if (!r.ok) return null;
  const user = await r.json();
  if (!user?.id) return null;
  return { userId: user.id };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '*';
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(origin) });
    if (request.method !== 'POST') return response({ error: 'Method not allowed' }, 405, origin);

    const identity = await verifyUser(env, request.headers.get('Authorization'));
    if (!identity) return response({ error: 'غير مصرح بالدخول' }, 401, origin);
    const staff = await getStaff(env, identity);
    if (!staff) return response({ error: 'الحساب غير موجود في موظفي Elora' }, 403, origin);

    const form = await request.formData();
    const file = form.get('file');
    const code = String(form.get('code') || 'image').trim();
    const folderRaw = String(form.get('folder') || 'general').trim().toLowerCase();
    const folder = ['products','categories','offers','banners','general'].includes(folderRaw) ? folderRaw : 'general';
    if (!hasPermission(staff, permissionFor(folder))) return response({ error: 'ليس لديك صلاحية رفع الصور لهذا القسم' }, 403, origin);
    if (!(file instanceof File)) return response({ error: 'لم يتم اختيار صورة' }, 400, origin);
    if (!file.type.startsWith('image/')) return response({ error: 'الملف المختار ليس صورة' }, 400, origin);
    if (file.size > 8 * 1024 * 1024) return response({ error: 'حجم الصورة أكبر من 8MB' }, 413, origin);

    const ext = file.type === 'image/webp' ? 'webp' : (file.type === 'image/png' ? 'png' : 'jpg');
    const safeCode = code.normalize('NFKC').replace(/[^\p{L}\p{N}_-]+/gu, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 80) || 'image';
    const key = `${folder}/${safeCode}-${crypto.randomUUID()}.${ext}`;
    await env.ELORA_IMAGES.put(key, file.stream(), { httpMetadata: { contentType: file.type } });
    const base = String(env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
    if (!base) return response({ error: 'PUBLIC_BASE_URL غير مضبوط في Worker' }, 500, origin);
    return response({ ok: true, key, url: `${base}/${key}` }, 200, origin);
  }
};
