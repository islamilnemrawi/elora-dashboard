# Elora Image Worker — Cloudflare R2

هذا الـWorker هو نقطة الرفع الآمنة التي يستخدمها Dashboard. التطبيق لا يحتوي على `service_role` أو مفاتيح R2.

## مرة واحدة فقط

1. أنشئ R2 bucket باسم `elora-images`.
2. اربط له Custom Domain عام للصور، وضعه في `PUBLIC_BASE_URL`.
3. من مجلد `worker` نفّذ:

```bash
wrangler secret put SUPABASE_URL
wrangler secret put SUPABASE_PUBLISHABLE_KEY
wrangler secret put SUPABASE_SERVICE_ROLE_KEY
wrangler deploy
```

4. انسخ رابط الـWorker الناتج وضعه في `app/src/main/assets/supabase-config.js` في `window.ELORA_IMAGE_UPLOAD_URL`.

بعد هذه الخطوة، الاستخدام اليومي لا يحتاج أي URL أو مسار: المستخدم يختار الصورة فقط، والـDashboard يتولى الباقي.

## الأمان

`SUPABASE_SERVICE_ROLE_KEY` يبقى داخل Cloudflare Worker فقط، ولا يوضع في التطبيق أو GitHub.
