begin;

-- ELORA OFFERS / HERO MANAGEMENT
-- Dashboard-controlled hero button, category target and display order.
alter table public.offers add column if not exists button_text text default 'اكتشف المجموعة';
alter table public.offers add column if not exists category text;
alter table public.offers add column if not exists sort_order integer not null default 0;
create index if not exists offers_active_sort_idx on public.offers (active, sort_order);

-- ELORA DASHBOARD FULL FIX
-- Adds persistence for payment/Prime settings, secure admin policies,
-- customer/Prime listing RPCs, and keeps the existing dashboard architecture.

alter table public.store_settings add column if not exists currency text default 'ج.م';
alter table public.store_settings add column if not exists payment_cod boolean not null default true;
alter table public.store_settings add column if not exists payment_vodafone boolean not null default true;
alter table public.store_settings add column if not exists payment_visa boolean not null default true;
alter table public.store_settings add column if not exists prime_price numeric(12,2) not null default 300;
alter table public.store_settings add column if not exists prime_discount numeric(5,2) not null default 10;
alter table public.store_settings add column if not exists prime_free_shipping_orders integer not null default 6;

-- Public catalog reads remain limited to active records.
alter table public.categories enable row level security;
drop policy if exists "Public can read active categories" on public.categories;
create policy "Public can read active categories" on public.categories
for select to anon, authenticated using (active = true);
drop policy if exists "Staff category select permission" on public.categories;
create policy "Staff category select permission" on public.categories as restrictive
for select to authenticated using (public.has_staff_permission('categories.view'));
drop policy if exists "Staff category insert permission" on public.categories;
create policy "Staff category insert permission" on public.categories as restrictive
for insert to authenticated with check (public.has_staff_permission('categories.manage'));
drop policy if exists "Staff category update permission" on public.categories;
create policy "Staff category update permission" on public.categories as restrictive
for update to authenticated using (public.has_staff_permission('categories.manage')) with check (public.has_staff_permission('categories.manage'));
drop policy if exists "Staff category delete permission" on public.categories;
create policy "Staff category delete permission" on public.categories as restrictive
for delete to authenticated using (public.has_staff_permission('categories.manage'));

alter table public.offers enable row level security;
drop policy if exists "Public can read active offers" on public.offers;
create policy "Public can read active offers" on public.offers
for select to anon, authenticated using (active = true);
drop policy if exists "Staff offer select permission" on public.offers;
create policy "Staff offer select permission" on public.offers as restrictive
for select to authenticated using (public.has_staff_permission('offers.view'));
drop policy if exists "Staff offer insert permission" on public.offers;
create policy "Staff offer insert permission" on public.offers as restrictive
for insert to authenticated with check (public.has_staff_permission('offers.manage'));
drop policy if exists "Staff offer update permission" on public.offers;
create policy "Staff offer update permission" on public.offers as restrictive
for update to authenticated using (public.has_staff_permission('offers.manage')) with check (public.has_staff_permission('offers.manage'));
drop policy if exists "Staff offer delete permission" on public.offers;
create policy "Staff offer delete permission" on public.offers as restrictive
for delete to authenticated using (public.has_staff_permission('offers.manage'));

alter table public.banners enable row level security;
drop policy if exists "Public can read active banners" on public.banners;
create policy "Public can read active banners" on public.banners
for select to anon, authenticated using (active = true);
drop policy if exists "Staff banner select permission" on public.banners;
create policy "Staff banner select permission" on public.banners as restrictive
for select to authenticated using (public.has_staff_permission('site.hero'));
drop policy if exists "Staff banner insert permission" on public.banners;
create policy "Staff banner insert permission" on public.banners as restrictive
for insert to authenticated with check (public.has_staff_permission('site.hero'));
drop policy if exists "Staff banner update permission" on public.banners;
create policy "Staff banner update permission" on public.banners as restrictive
for update to authenticated using (public.has_staff_permission('site.hero')) with check (public.has_staff_permission('site.hero'));
drop policy if exists "Staff banner delete permission" on public.banners;
create policy "Staff banner delete permission" on public.banners as restrictive
for delete to authenticated using (public.has_staff_permission('site.hero'));

alter table public.shipping_centers enable row level security;
drop policy if exists "Public can read active shipping centers" on public.shipping_centers;
create policy "Public can read active shipping centers" on public.shipping_centers
for select to anon, authenticated using (active = true);
drop policy if exists "Staff shipping select permission" on public.shipping_centers;
create policy "Staff shipping select permission" on public.shipping_centers as restrictive
for select to authenticated using (public.has_staff_permission('shipping.view'));
drop policy if exists "Staff shipping insert permission" on public.shipping_centers;
create policy "Staff shipping insert permission" on public.shipping_centers as restrictive
for insert to authenticated with check (public.has_staff_permission('shipping.manage'));
drop policy if exists "Staff shipping update permission" on public.shipping_centers;
create policy "Staff shipping update permission" on public.shipping_centers as restrictive
for update to authenticated using (public.has_staff_permission('shipping.manage')) with check (public.has_staff_permission('shipping.manage'));
drop policy if exists "Staff shipping delete permission" on public.shipping_centers;
create policy "Staff shipping delete permission" on public.shipping_centers as restrictive
for delete to authenticated using (public.has_staff_permission('shipping.manage'));

alter table public.store_settings enable row level security;
drop policy if exists "Public can read store settings" on public.store_settings;
create policy "Public can read store settings" on public.store_settings
for select to anon, authenticated using (true);
drop policy if exists "Staff settings select permission" on public.store_settings;
create policy "Staff settings select permission" on public.store_settings as restrictive
for select to authenticated using (public.has_staff_permission('settings.manage') or public.has_staff_permission('payments.view') or public.has_staff_permission('prime.view'));
drop policy if exists "Staff settings insert permission" on public.store_settings;
create policy "Staff settings insert permission" on public.store_settings as restrictive
for insert to authenticated with check (public.has_staff_permission('settings.manage') or public.has_staff_permission('payments.manage') or public.has_staff_permission('prime.manage'));
drop policy if exists "Staff settings update permission" on public.store_settings;
create policy "Staff settings update permission" on public.store_settings as restrictive
for update to authenticated using (public.has_staff_permission('settings.manage') or public.has_staff_permission('payments.manage') or public.has_staff_permission('prime.manage')) with check (public.has_staff_permission('settings.manage') or public.has_staff_permission('payments.manage') or public.has_staff_permission('prime.manage'));

alter table public.prime_subscriptions enable row level security;
drop policy if exists "Staff prime select permission" on public.prime_subscriptions;
create policy "Staff prime select permission" on public.prime_subscriptions as restrictive
for select to authenticated using (public.has_staff_permission('prime.view'));
drop policy if exists "Staff prime update permission" on public.prime_subscriptions;
create policy "Staff prime update permission" on public.prime_subscriptions as restrictive
for update to authenticated using (public.has_staff_permission('prime.manage')) with check (public.has_staff_permission('prime.manage'));

-- Customers are stored in Supabase Auth. The dashboard gets a safe read-only list through RPC.
create or replace function public.admin_list_customers()
returns table(user_id uuid, email text, created_at timestamptz, last_sign_in_at timestamptz, prime_active boolean)
language sql security definer stable
set search_path = public, auth
as $$
  select u.id, u.email, u.created_at, u.last_sign_in_at,
         exists(select 1 from public.prime_subscriptions ps where ps.user_id=u.id and ps.active=true and ps.expires_at > now())
  from auth.users u
  where public.has_staff_permission('customers.view')
  order by u.created_at desc;
$$;
revoke all on function public.admin_list_customers() from public;
grant execute on function public.admin_list_customers() to authenticated;

create or replace function public.admin_list_prime_subscriptions()
returns table(id uuid, user_id uuid, email text, started_at timestamptz, expires_at timestamptz, active boolean)
language sql security definer stable
set search_path = public, auth
as $$
  select ps.id, ps.user_id, u.email, ps.started_at, ps.expires_at, ps.active
  from public.prime_subscriptions ps
  left join auth.users u on u.id=ps.user_id
  where public.has_staff_permission('prime.view')
  order by ps.created_at desc;
$$;
revoke all on function public.admin_list_prime_subscriptions() from public;
grant execute on function public.admin_list_prime_subscriptions() to authenticated;


-- Staff with staff.view can read the staff list; only staff.manage can modify it.
drop policy if exists "Staff view profiles" on public.staff_profiles;
create policy "Staff view profiles" on public.staff_profiles as restrictive
for select to authenticated using (public.has_staff_permission('staff.view') or id=auth.uid());

commit;

select 'Elora Dashboard full fix migration completed successfully' as status;
