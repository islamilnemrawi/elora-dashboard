begin;

-- ELORA shipping + visual editor production migration
create table if not exists public.shipping_governorates (governorate text primary key, price numeric(12,2) not null default 0, centers_enabled boolean not null default true, active boolean not null default true, updated_at timestamptz not null default now());
alter table public.shipping_centers alter column center drop not null;
alter table public.shipping_centers add column if not exists active boolean not null default true;
alter table public.shipping_centers add column if not exists price numeric(12,2) not null default 0;
create unique index if not exists uq_shipping_centers_governorate_center on public.shipping_centers(governorate,center);

alter table public.shipping_governorates enable row level security;
drop policy if exists "Public can read active shipping governorates" on public.shipping_governorates;
create policy "Public can read active shipping governorates" on public.shipping_governorates for select to anon, authenticated using (active = true);
drop policy if exists "Staff shipping governorate insert" on public.shipping_governorates;
create policy "Staff shipping governorate insert" on public.shipping_governorates as restrictive for insert to authenticated with check (public.has_staff_permission('shipping.manage'));
drop policy if exists "Staff shipping governorate update" on public.shipping_governorates;
create policy "Staff shipping governorate update" on public.shipping_governorates as restrictive for update to authenticated using (public.has_staff_permission('shipping.manage')) with check (public.has_staff_permission('shipping.manage'));

alter table public.site_customizations enable row level security;
drop policy if exists "Public can read site customizations" on public.site_customizations;
create policy "Public can read site customizations" on public.site_customizations for select to anon, authenticated using (true);
drop policy if exists "Staff site customizations insert" on public.site_customizations;
create policy "Staff site customizations insert" on public.site_customizations as restrictive for insert to authenticated with check (public.has_staff_permission('site.edit'));
drop policy if exists "Staff site customizations update" on public.site_customizations;
create policy "Staff site customizations update" on public.site_customizations as restrictive for update to authenticated using (public.has_staff_permission('site.edit')) with check (public.has_staff_permission('site.edit'));

insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('القاهرة',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الجيزة',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الإسكندرية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('القليوبية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الدقهلية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الشرقية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الغربية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('المنوفية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('البحيرة',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('كفر الشيخ',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('دمياط',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('بورسعيد',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الإسماعيلية',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('السويس',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الفيوم',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('بني سويف',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('المنيا',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('أسيوط',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('سوهاج',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('قنا',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الأقصر',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('أسوان',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('مطروح',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('الوادي الجديد',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('شمال سيناء',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('جنوب سيناء',0,true,true) on conflict (governorate) do nothing;
insert into public.shipping_governorates(governorate,price,centers_enabled,active) values ('البحر الأحمر',0,true,true) on conflict (governorate) do nothing;








































































































































































































































































-- Complete ELORA delivery-area catalog: 27 governorates + Cairo administrative districts/new cities + Madinaty
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','مدينة نصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','مصر الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','المعادي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','حلوان',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','شبرا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الساحل',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الزيتون',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','عين شمس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','المطرية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','النزهة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','التجمع',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','المقطم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','المرج',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','البساتين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','دار السلام',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','وسط القاهرة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','غرب مدينة نصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','شرق مدينة نصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','السلام أول',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','السلام ثان',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','منشأة ناصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الوايلي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','بولاق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','غرب القاهرة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','عابدين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الأزبكية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الموسكي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','باب الشعرية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','مصر القديمة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الخليفة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','السيدة زينب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','التبين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','المعصرة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','طرة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','15 مايو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الزاوية الحمراء',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','حدائق القبة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','روض الفرج',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الشرابية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الأميرية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','القاهرة الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','التجمع الأول',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','التجمع الخامس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','مدينتي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','الشروق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القاهرة','بدر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الجيزة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الدقي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','العجوزة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الهرم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','بولاق الدكرور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','العمرانية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','إمبابة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الوراق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','كرداسة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','أوسيم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','منشأة القناطر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','أبو النمرس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الحوامدية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','البدرشين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','العياط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الصف',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','أطفيح',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','6 أكتوبر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الجيزة','الشيخ زايد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','المنتزه أول',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','المنتزه ثان',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','شرق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','وسط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','غرب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','الجمرك',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','العجمي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','العامرية أول',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','العامرية ثان',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسكندرية','برج العرب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','بنها',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','شبرا الخيمة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','قليوب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','القناطر الخيرية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','الخانكة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','الخصوص',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','شبين القناطر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','طوخ',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','كفر شكر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('القليوبية','العبور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','المنصورة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','طلخا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','ميت غمر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','أجا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','السنبلاوين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','دكرنس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','منية النصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','الجمالية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','المطرية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','بلقاس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','شربين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','نبروه',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','تمي الأمديد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','بني عبيد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','ميت سلسيل',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الدقهلية','محلة دمنة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','الزقازيق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','بلبيس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','منيا القمح',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','فاقوس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','أبو كبير',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','ههيا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','مشتول السوق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','أبو حماد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','ديرب نجم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','كفر صقر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','الحسينية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','صان الحجر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','الإبراهيمية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','القنايات',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الشرقية','أولاد صقر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','طنطا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','المحلة الكبرى',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','كفر الزيات',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','زفتى',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','السنطة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','سمنود',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','قطور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الغربية','بسيون',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','شبين الكوم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','منوف',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','السادات',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','أشمون',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','الباجور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','قويسنا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','بركة السبع',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','تلا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنوفية','الشهداء',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','دمنهور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','كفر الدوار',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','رشيد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','إدكو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','أبو المطامير',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','أبو حمص',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','حوش عيسى',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','الدلنجات',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','المحمودية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','إيتاي البارود',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','شبراخيت',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','كوم حمادة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','بدر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','وادي النطرون',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','النوبارية الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحيرة','الرحمانية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','كفر الشيخ',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','دسوق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','فوه',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','مطوبس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','بلطيم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','الحامول',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','بيلا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','سيدي سالم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','قلين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','الرياض',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('كفر الشيخ','البرلس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','دمياط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','دمياط الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','رأس البر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','فارسكور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','الزرقا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','كفر سعد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','كفر البطيخ',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('دمياط','السرو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي الشرق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي العرب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي المناخ',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي الضواحي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي الزهور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بورسعيد','حي الجنوب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','الإسماعيلية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','فايد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','القنطرة شرق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','القنطرة غرب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','التل الكبير',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','أبو صوير',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الإسماعيلية','القصاصين الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('السويس','حي السويس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('السويس','حي الأربعين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('السويس','حي عتاقة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('السويس','حي فيصل',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('السويس','حي الجناين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','الفيوم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','سنورس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','إطسا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','طامية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','أبشواي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الفيوم','يوسف الصديق',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','بني سويف',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','الواسطى',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','ناصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','إهناسيا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','ببا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','الفشن',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('بني سويف','سمسطا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','المنيا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','ملوي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','سمالوط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','أبو قرقاص',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','مغاغة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','بني مزار',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','مطاي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','العدوة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('المنيا','دير مواس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','أسيوط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','ديروط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','القوصية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','منفلوط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','أبنوب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','الفتح',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','ساحل سليم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','البداري',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','صدفا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','الغنايم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسيوط','أبو تيج',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','سوهاج',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','أخميم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','جرجا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','طهطا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','المراغة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','البلينا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','المنشأة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','جهينة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','ساقلتة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('سوهاج','دار السلام',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','قنا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','نجع حمادي',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','دشنا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','قفط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','قوص',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','نقادة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','أبو تشت',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','فرشوط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('قنا','الوقف',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','الأقصر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','الأقصر الجديدة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','إسنا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','أرمنت',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','الطود',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','البياضية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الأقصر','القرنة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','أسوان',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','دراو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','كوم أمبو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','نصر النوبة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','إدفو',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('أسوان','أبو سمبل السياحية',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','مرسى مطروح',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','الحمام',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','العلمين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','الضبعة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','النجيلة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','سيدي براني',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','السلوم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('مطروح','سيوة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الوادي الجديد','الخارجة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الوادي الجديد','الداخلة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الوادي الجديد','الفرافرة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الوادي الجديد','باريس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('الوادي الجديد','بلاط',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','العريش',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','بئر العبد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','الشيخ زويد',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','رفح',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','الحسنة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('شمال سيناء','نخل',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','الطور',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','شرم الشيخ',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','دهب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','نويبع',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','طابا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','سانت كاترين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','رأس سدر',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','أبو زنيمة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('جنوب سيناء','أبو رديس',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','الغردقة',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','رأس غارب',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','سفاجا',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','القصير',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','مرسى علم',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','الشلاتين',0,true) on conflict (governorate,center) do nothing;
insert into public.shipping_centers(governorate,center,price,active) values ('البحر الأحمر','حلايب',0,true) on conflict (governorate,center) do nothing;

commit;


