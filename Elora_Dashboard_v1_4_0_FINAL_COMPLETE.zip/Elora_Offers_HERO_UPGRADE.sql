-- ELORA OFFERS / HERO UPGRADE
-- Run this once in Supabase SQL Editor.
-- It is safe to run more than once.

begin;

alter table public.offers
  add column if not exists button_text text default 'اكتشف المجموعة';

alter table public.offers
  add column if not exists category text;

alter table public.offers
  add column if not exists sort_order integer not null default 0;

create index if not exists offers_active_sort_idx
  on public.offers (active, sort_order);

update public.offers
set button_text = 'اكتشف المجموعة'
where button_text is null or trim(button_text) = '';

commit;
