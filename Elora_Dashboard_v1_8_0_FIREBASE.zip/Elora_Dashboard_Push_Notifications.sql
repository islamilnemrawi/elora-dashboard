-- Elora Dashboard push notification devices
-- Run once in Supabase SQL Editor.

create table if not exists public.dashboard_push_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique,
  platform text not null default 'android',
  active boolean not null default true,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists dashboard_push_devices_user_idx
  on public.dashboard_push_devices(user_id, active);

alter table public.dashboard_push_devices enable row level security;

drop policy if exists "Staff manage own push devices" on public.dashboard_push_devices;
create policy "Staff manage own push devices"
  on public.dashboard_push_devices
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- The server-side notification sender should use the service role and can read
-- active device tokens for the staff member(s) that should receive order alerts.
