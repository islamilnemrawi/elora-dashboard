package com.elora.dashboard;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private WebViewAssetLoader assetLoader;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 2002;
    private static final String NOTIFICATION_CHANNEL_ID = "elora_orders";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        webView = new WebView(this);
        setContentView(webView);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        configureWebView();
        createNotificationChannel();
        initializeFirebaseFromBundledConfig();
        requestNotificationPermission();
        webView.addJavascriptInterface(new AndroidDashboardBridge(), "AndroidDashboard");
        webView.loadUrl("https://appassets.androidplatform.net/assets/Elora_Dashboard.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        // Required for the local website preview iframe inside the dashboard.
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " EloraDashboard/1.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Keep the local WebViewAssetLoader origin inside the WebView.
                // Treating appassets.androidplatform.net as an external URL causes
                // Android to show a permission error on the visual editor iframe.
                if ("https".equalsIgnoreCase(scheme)
                        && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    view.loadUrl(uri.toString());
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        // The dashboard owns its own in-app history. Always ask the page first
        // so Android's physical back button works on every dashboard screen.
        webView.evaluateJavascript("(function(){if(typeof window.dashboardGoBack==='function'){window.dashboardGoBack();return 'handled'}return 'not-handled'})();", value -> {
            if ("\"not-handled\"".equals(value) || value == null) {
                if (webView != null && webView.canGoBack()) webView.goBack();
                else finish();
            }
        });
    }

    public class AndroidDashboardBridge {
        @JavascriptInterface
        public void goBack() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            MainActivity.this.requestNotificationPermission();
        }

        @JavascriptInterface
        public void showOrderNotification(String title, String body, String orderNumber) {
            runOnUiThread(() -> postOrderNotification(title, body, orderNumber));
        }

        @JavascriptInterface
        public void registerPushToken(final String callbackName) {
            if (!isFirebaseReady()) {
                callJs(callbackName, "");
                return;
            }
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                String token = task.isSuccessful() ? task.getResult() : "";
                if (token == null) token = "";
                getSharedPreferences("elora_push", MODE_PRIVATE)
                        .edit().putString("fcm_token", token).apply();
                callJs(callbackName, token);
            });
        }

        @JavascriptInterface
        public boolean isPushConfigured() {
            return isFirebaseReady();
        }
    }

    private void callJs(String callbackName, String value) {
        if (webView == null) return;
        String safeName = callbackName == null ? "" : callbackName.replaceAll("[^A-Za-z0-9_$]", "");
        String safeValue = JSONObject.quote(value == null ? "" : value);
        if (safeName.isEmpty()) return;
        webView.post(() -> webView.evaluateJavascript(
                "if(typeof window[\"" + safeName + "\"]===\"function\"){window[\"" + safeName + "\"](" + safeValue + ");}", null));
    }

    private boolean isFirebaseReady() {
        try {
            return !FirebaseApp.getApps(this).isEmpty();
        } catch (Exception ignored) {
            return false;
        }
    }

    private void initializeFirebaseFromBundledConfig() {
        try {
            if (isFirebaseReady()) return;
            InputStream input = getAssets().open("firebase-config.json");
            byte[] bytes = new byte[input.available()];
            int read = input.read(bytes);
            input.close();
            if (read <= 0) return;
            JSONObject root = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            JSONObject project = root.optJSONObject("project_info");
            JSONObject client = root.optJSONArray("client") != null && root.optJSONArray("client").length() > 0
                    ? root.optJSONArray("client").optJSONObject(0) : null;
            JSONObject clientInfo = client == null ? null : client.optJSONObject("client_info");
            JSONObject api = client == null || client.optJSONArray("api_key") == null || client.optJSONArray("api_key").length() == 0
                    ? null : client.optJSONArray("api_key").optJSONObject(0);
            if (project == null || clientInfo == null || api == null) return;
            String appId = clientInfo.optString("mobilesdk_app_id", "");
            String projectId = project.optString("project_id", "");
            String senderId = project.optString("project_number", "");
            String apiKey = api.optString("current_key", "");
            if (appId.isEmpty() || projectId.isEmpty() || senderId.isEmpty() || apiKey.isEmpty()) return;
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApplicationId(appId)
                    .setProjectId(projectId)
                    .setGcmSenderId(senderId)
                    .setApiKey(apiKey)
                    .build();
            FirebaseApp.initializeApp(this, options);
            FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        } catch (Exception ignored) {
            // Firebase is optional until firebase-config.json is supplied.
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "طلبات Elora",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("إشعارات الطلبات الجديدة في متجر Elora");
            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{"android.permission.POST_NOTIFICATIONS"},
                    NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private void postOrderNotification(String title, String body, String orderNumber) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("open_orders", true);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 8001, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String text = body == null ? "وصل طلب جديد إلى متجرك." : body;
        if (orderNumber != null && !orderNumber.trim().isEmpty()) text += "  #" + orderNumber;
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_elora)
                .setContentTitle(title == null || title.isEmpty() ? "طلب جديد في Elora" : title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
