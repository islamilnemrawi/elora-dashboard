// Elora order push sender for Cloudflare Workers.
// Secrets required in Worker environment:
// SUPABASE_URL
// SUPABASE_SERVICE_ROLE_KEY
// ELORA_PUSH_WEBHOOK_SECRET
// FCM_PROJECT_ID
// FCM_CLIENT_EMAIL
// FCM_PRIVATE_KEY

const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8' };

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });
}

function base64Url(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function textBase64Url(text) {
  return base64Url(new TextEncoder().encode(text));
}

function pemToBytes(pem) {
  const clean = pem
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\s+/g, '');
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function getAccessToken(env) {
  const now = Math.floor(Date.now() / 1000);
  const header = textBase64Url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = textBase64Url(JSON.stringify({
    iss: env.FCM_CLIENT_EMAIL,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600
  }));
  const unsigned = `${header}.${claim}`;

  const key = await crypto.subtle.importKey(
    'pkcs8',
    pemToBytes(env.FCM_PRIVATE_KEY.replace(/\\n/g, '\n')),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    key,
    new TextEncoder().encode(unsigned)
  );

  const assertion = `${unsigned}.${base64Url(new Uint8Array(signature))}`;
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion
    })
  });

  if (!response.ok) throw new Error(`FCM OAuth failed: ${response.status}`);
  const data = await response.json();
  if (!data.access_token) throw new Error('FCM access token missing');
  return data.access_token;
}

async function sendOrderPush(env, order) {
  const devicesResponse = await fetch(
    `${env.SUPABASE_URL}/rest/v1/dashboard_push_devices?select=token&active=eq.true&platform=eq.android`,
    {
      headers: {
        apikey: env.SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`
      }
    }
  );

  if (!devicesResponse.ok) throw new Error('Could not read push devices');
  const devices = await devicesResponse.json();
  const tokens = [...new Set((devices || []).map(x => x.token).filter(Boolean))];
  if (!tokens.length) return { sent: 0, tokens: 0 };

  const accessToken = await getAccessToken(env);
  const orderNumber = order.order_number || order.id || '—';
  const customer = order.customer_name || order.name || 'عميل جديد';
  const total = Number(order.total || order.grand_total || 0).toLocaleString('ar-EG');

  let sent = 0;
  const invalid = [];

  for (const token of tokens) {
    const response = await fetch(
      `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(env.FCM_PROJECT_ID)}/messages:send`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'content-type': 'application/json'
        },
        body: JSON.stringify({
          message: {
            token,
            notification: {
              title: 'طلب جديد في Elora',
              body: `طلب #${orderNumber} من ${customer} بقيمة ${total} ج.م`
            },
            data: {
              type: 'new_order',
              order_number: String(orderNumber)
            },
            android: {
              priority: 'high',
              notification: {
                channel_id: 'elora_orders'
              }
            }
          }
        })
      }
    );

    if (response.ok) {
      sent++;
    } else {
      const body = await response.text();
      if (/UNREGISTERED|INVALID_ARGUMENT/.test(body)) invalid.push(token);
    }
  }

  if (invalid.length) {
    const encoded = invalid.map(t => encodeURIComponent(t)).join(',');
    // Keep cleanup best-effort; tokens are not exposed in logs.
    await fetch(`${env.SUPABASE_URL}/rest/v1/dashboard_push_devices?token=in.(${encoded})`, {
      method: 'PATCH',
      headers: {
        apikey: env.SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
        'content-type': 'application/json',
        Prefer: 'return=minimal'
      },
      body: JSON.stringify({ active: false })
    });
  }

  return { sent, tokens: tokens.length, invalid: invalid.length };
}

export async function handleOrderPush(request, env) {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  if (!env.ELORA_PUSH_WEBHOOK_SECRET || request.headers.get('X-Elora-Push-Secret') !== env.ELORA_PUSH_WEBHOOK_SECRET) {
    return json({ error: 'Unauthorized' }, 401);
  }

  const payload = await request.json();
  const order = payload?.record || payload?.new || payload?.order || payload;
  if (!order?.id && !order?.order_number) return json({ error: 'Order payload missing' }, 400);

  try {
    const result = await sendOrderPush(env, order);
    return json({ ok: true, ...result });
  } catch (error) {
    return json({ ok: false, error: error.message || 'Push failed' }, 500);
  }
}
