# Elora Push Sender — Cloudflare Worker

The Worker now exposes `POST /notify-order` for sending new-order notifications through Firebase Cloud Messaging.

## Required Worker secrets/variables

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `ELORA_PUSH_WEBHOOK_SECRET`
- `FCM_PROJECT_ID`
- `FCM_CLIENT_EMAIL`
- `FCM_PRIVATE_KEY`

`FCM_PRIVATE_KEY` is the private key from the Firebase/Google service account JSON. Store it as a Worker secret; never commit it.

## Supabase webhook

Create a Database Webhook for `public.orders` on `INSERT` and POST the JSON payload to:

`https://YOUR-WORKER-DOMAIN/notify-order`

with header:

`X-Elora-Push-Secret: YOUR_ELORA_PUSH_WEBHOOK_SECRET`

The Worker reads active Android tokens from `dashboard_push_devices` and sends an FCM HTTP v1 message.
