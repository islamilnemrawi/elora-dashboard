# Elora Dashboard — إشعارات الطلبات

تمت إضافة بنية إشعارات Android وFirebase Cloud Messaging (FCM) + إشعار محلي فوري عند وصول INSERT جديد في جدول `orders` أثناء تشغيل الداشبورد.

## لكي تصل الإشعارات حتى لو التطبيق في الخلفية/مغلق

لازم مرة واحدة إعداد Firebase، لأن Android لا يستطيع إرسال Push حقيقي من Supabase مباشرة إلى الهاتف بدون مزود Push.

1. أنشئ/افتح مشروع Firebase.
2. أضف Android App بالـPackage Name:
   `com.elora.dashboard`
3. حمّل `google-services.json`.
4. ضعه داخل:
   `app/google-services.json`
5. في نسخة GitHub الحالية، يمكن للـworkflow نسخه تلقائيًا إلى assets باسم `firebase-config.json` في خطوة لاحقة.
6. يجب أيضًا تجهيز sender server (Supabase Edge Function أو Cloudflare Worker) لاستخدام Firebase HTTP v1 وإرسال الرسالة إلى التوكنات الموجودة في `dashboard_push_devices`.

## قاعدة البيانات

شغّل:
`Elora_Dashboard_Push_Notifications.sql`

الجدول يحفظ FCM token الخاص بكل جهاز للموظف المسجل.

## ملاحظة مهمة

ملف `google-services.json` يحتوي معرفات إعداد Firebase غير سرية بحد ذاتها، لكن مفاتيح إرسال FCM الخاصة بالسيرفر (Service Account credentials) لا توضع داخل التطبيق أو GitHub؛ تحفظ كـSecrets في بيئة السيرفر.
