-- Elora Dashboard v1.9.5
-- Securely registers the current authenticated user's Android FCM token.
-- Run this ONCE in Supabase SQL Editor.

create or replace function public.register_dashboard_push_device(
  p_token text,
  p_platform text default 'android'
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  if p_token is null or length(trim(p_token)) < 20 then
    raise exception 'INVALID_FCM_TOKEN';
  end if;

  insert into public.dashboard_push_devices
    (user_id, token, platform, active, last_seen_at, updated_at)
  values
    (v_user_id, trim(p_token), coalesce(nullif(trim(p_platform), ''), 'android'), true, now(), now())
  on conflict (token) do update set
    user_id = excluded.user_id,
    platform = excluded.platform,
    active = true,
    last_seen_at = now(),
    updated_at = now();

  return jsonb_build_object('ok', true, 'user_id', v_user_id);
end;
$$;

revoke all on function public.register_dashboard_push_device(text, text) from public;
grant execute on function public.register_dashboard_push_device(text, text) to authenticated;
