# Elora Dashboard — GitHub Ready

هذه النسخة مبنية من الـDashboard الحالي مع **تعديلات واجهة فقط**:
- إزالة تداخل عنوان الصفحة مع الهيدر في الرئيسية.
- تكبير وضبط أيقونات مركز التحكم ومحاذاتها في المنتصف.
- ضبط أيقونات بطاقات الإحصائيات بدون تغيير بيانات أو وظائف الأقسام.

قاعدة Supabase وFirebase الحالية موجودة في `app/src/main/assets/` كما كانت في النسخة الحالية.

## Build
ارفع محتويات هذا المجلد إلى مستودع GitHub، ثم شغّل Actions → Build Elora Dashboard APK.

## v1.9.9 database migration
Before testing employee/shipping management, run `SUPABASE_V1_9_9_FIX.sql` once in the Supabase SQL Editor using the project owner/postgres role. This creates the SECURITY DEFINER admin RPCs required for staff and shipping writes and the authenticated read policies used by the dashboard. The Android UI/theme is unchanged.
