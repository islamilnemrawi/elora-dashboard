package com.elora.dashboard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.SharedPreferences;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class EloraFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID="elora_orders";
    @Override public void onMessageReceived(RemoteMessage m){
        String title=m.getNotification()!=null?m.getNotification().getTitle():"طلب جديد في Elora";
        String body=m.getNotification()!=null?m.getNotification().getBody():"وصل طلب جديد إلى لوحة التحكم";
        String number=m.getData().get("order_number"); if(number==null) number="";
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"طلبات Elora",NotificationManager.IMPORTANCE_HIGH));
        Intent i=new Intent(this,MainActivity.class); i.putExtra("order_number",number);
        PendingIntent pi=PendingIntent.getActivity(this,Math.abs(number.hashCode()),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_elora).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        nm.notify(Math.abs(number.hashCode()),b.build());
    }
    @Override public void onNewToken(String token){
        super.onNewToken(token);
        getSharedPreferences("elora_push", MODE_PRIVATE).edit().putString("token", token).apply();
        // MainActivity may be alive while FCM rotates the token. Ask the WebView to
        // persist the new token through the authenticated Supabase session.
        android.content.SharedPreferences p=getSharedPreferences("elora_push", MODE_PRIVATE);
        android.os.Handler h=new android.os.Handler(getMainLooper());
        h.postDelayed(() -> {
            try {
                android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
                // The normal registration path also calls getToken(), so no UI action is required here.
            } catch(Exception ignored) {}
        }, 250);
    }
}
