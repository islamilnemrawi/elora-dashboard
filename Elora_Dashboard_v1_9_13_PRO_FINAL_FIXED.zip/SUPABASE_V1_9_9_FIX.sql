-- Elora Dashboard v1.9.9 functional fixes
-- Run once in Supabase SQL Editor using the project owner/postgres role.
-- No store/customer UI changes are made by this migration.

create or replace function public.elora_is_staff_manager()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare r record;
begin
  select role, active, permissions into r
  from public.staff_profiles
  where id = auth.uid();
  if not found or coalesce(r.active,false) = false then return false; end if;
  if lower(coalesce(r.role,'')) in ('owner','admin','manager') then return true; end if;
  return coalesce((r.permissions ->> 'staff.manage')::boolean,false)
     or coalesce((r.permissions ->> 'shipping.manage')::boolean,false);
exception when others then
  return false;
end;
$$;

grant execute on function public.elora_is_staff_manager() to authenticated;

create or replace function public.admin_list_staff_profiles()
returns table(id uuid,email text,name text,role text,permissions jsonb,active boolean,updated_at timestamptz,created_at timestamptz)
language plpgsql
security definer
set search_path = public, auth
as $$
declare r record;
begin
  select role, active, permissions into r from public.staff_profiles where id = auth.uid();
  if not found or coalesce(r.active,false)=false then raise exception 'ليس لديك صلاحية إدارة الموظفين'; end if;
  if lower(coalesce(r.role,'')) not in ('owner','admin','manager') and not coalesce((r.permissions->>'staff.manage')::boolean,false) then
    raise exception 'ليس لديك صلاحية إدارة الموظفين';
  end if;
  return query select sp.id,sp.email,sp.name,sp.role,sp.permissions,sp.active,sp.updated_at,sp.created_at
  from public.staff_profiles sp order by sp.created_at desc;
end;
$$;

grant execute on function public.admin_list_staff_profiles() to authenticated;

create or replace function public.admin_upsert_staff_by_email(
  p_email text,
  p_name text default null,
  p_role text default 'staff',
  p_permissions jsonb default '{}'::jsonb,
  p_active boolean default true
)
returns public.staff_profiles
language plpgsql
security definer
set search_path = public, auth
as $$
declare caller record; u record; result public.staff_profiles;
begin
  select role,active,permissions into caller from public.staff_profiles where id=auth.uid();
  if not found or coalesce(caller.active,false)=false then raise exception 'ليس لديك صلاحية إدارة الموظفين'; end if;
  if lower(coalesce(caller.role,'')) not in ('owner','admin','manager') and not coalesce((caller.permissions->>'staff.manage')::boolean,false) then
    raise exception 'ليس لديك صلاحية إدارة الموظفين';
  end if;
  select id,email into u from auth.users where lower(email)=lower(trim(p_email)) limit 1;
  if not found then raise exception 'لا يوجد حساب مسجل بهذا البريد الإلكتروني في Auth'; end if;
  if u.id=auth.uid() and lower(coalesce(p_role,'')) not in ('owner','admin','manager') then
    raise exception 'لا يمكن تحويل حساب المالك إلى موظف';
  end if;
  insert into public.staff_profiles(id,email,name,role,permissions,active,updated_at)
  values(u.id,u.email,p_name,coalesce(nullif(lower(trim(p_role)),''),'staff'),coalesce(p_permissions,'{}'::jsonb),coalesce(p_active,true),now())
  on conflict(id) do update set email=excluded.email,name=excluded.name,role=excluded.role,permissions=excluded.permissions,active=excluded.active,updated_at=now()
  returning * into result;
  return result;
end;
$$;

grant execute on function public.admin_upsert_staff_by_email(text,text,text,jsonb,boolean) to authenticated;

create or replace function public.admin_upsert_shipping_governorate(
  p_governorate text,
  p_price numeric,
  p_active boolean default true,
  p_centers_enabled boolean default true
)
returns public.shipping_governorates
language plpgsql
security definer
set search_path = public
as $$
declare result public.shipping_governorates;
begin
  if not public.elora_is_staff_manager() then raise exception 'ليس لديك صلاحية إدارة الشحن'; end if;
  if nullif(trim(p_governorate),'') is null then raise exception 'اسم المحافظة مطلوب'; end if;
  if p_price is null or p_price < 0 then raise exception 'سعر الشحن غير صحيح'; end if;
  insert into public.shipping_governorates(governorate,price,active,centers_enabled,updated_at)
  values(trim(p_governorate),p_price,coalesce(p_active,true),coalesce(p_centers_enabled,true),now())
  on conflict(governorate) do update set price=excluded.price,active=excluded.active,centers_enabled=excluded.centers_enabled,updated_at=now()
  returning * into result;
  return result;
end;
$$;

grant execute on function public.admin_upsert_shipping_governorate(text,numeric,boolean,boolean) to authenticated;

create or replace function public.admin_upsert_shipping_center(
  p_id uuid default null,
  p_governorate text default null,
  p_center text default null,
  p_price numeric default 0,
  p_active boolean default true
)
returns public.shipping_centers
language plpgsql
security definer
set search_path = public
as $$
declare result public.shipping_centers;
begin
  if not public.elora_is_staff_manager() then raise exception 'ليس لديك صلاحية إدارة الشحن'; end if;
  if nullif(trim(p_governorate),'') is null or nullif(trim(p_center),'') is null then raise exception 'المحافظة والمركز مطلوبان'; end if;
  if p_price is null or p_price < 0 then raise exception 'سعر الشحن غير صحيح'; end if;
  if p_id is not null then
    update public.shipping_centers set governorate=trim(p_governorate),center=trim(p_center),price=p_price,active=coalesce(p_active,true)
    where id=p_id returning * into result;
    if found then return result; end if;
  end if;
  insert into public.shipping_centers(governorate,center,price,active)
  values(trim(p_governorate),trim(p_center),p_price,coalesce(p_active,true))
  on conflict(governorate,center) do update set price=excluded.price,active=excluded.active
  returning * into result;
  return result;
end;
$$;

grant execute on function public.admin_upsert_shipping_center(uuid,text,text,numeric,boolean) to authenticated;

create or replace function public.admin_delete_shipping_center(p_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.elora_is_staff_manager() then raise exception 'ليس لديك صلاحية إدارة الشحن'; end if;
  delete from public.shipping_centers where id=p_id;
  return found;
end;
$$;

grant execute on function public.admin_delete_shipping_center(uuid) to authenticated;

-- Read policies: active dashboard staff can read shipping data.
grant select on public.shipping_governorates, public.shipping_centers to authenticated;
alter table public.shipping_governorates enable row level security;
alter table public.shipping_centers enable row level security;
drop policy if exists "elora_staff_read_shipping_governorates" on public.shipping_governorates;
create policy "elora_staff_read_shipping_governorates" on public.shipping_governorates for select to authenticated using (public.elora_is_staff_manager() or exists(select 1 from public.staff_profiles sp where sp.id=auth.uid() and sp.active=true));
drop policy if exists "elora_staff_read_shipping_centers" on public.shipping_centers;
create policy "elora_staff_read_shipping_centers" on public.shipping_centers for select to authenticated using (public.elora_is_staff_manager() or exists(select 1 from public.staff_profiles sp where sp.id=auth.uid() and sp.active=true));

-- Orders read access used by Dashboard.
grant select on public.orders to authenticated;
alter table public.orders enable row level security;
drop policy if exists "elora_staff_read_orders" on public.orders;
create policy "elora_staff_read_orders" on public.orders for select to authenticated using (exists(select 1 from public.staff_profiles sp where sp.id=auth.uid() and sp.active=true));
