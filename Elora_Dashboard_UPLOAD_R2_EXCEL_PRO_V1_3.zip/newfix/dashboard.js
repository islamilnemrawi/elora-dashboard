



let orders=[], products=[], coupons=[], categories=[], offers=[], banners=[], shippingCenters=[], customers=[], primeSubscriptions=[];
let editingCategoryId=null, editingOfferId=null, editingBannerId=null, editingShippingId=null;
let editingCouponId=null;
const titles={home:"الرئيسية",reports:"التقارير والأرباح",orders:"الطلبات",products:"المنتجات",categories:"الأقسام",offers:"العروض والبنرات",coupons:"أكواد الخصم",customers:"العملاء",prime:"Elora Prime",shipping:"الشحن",payments:"الدفع",staff:"الموظفون والصلاحيات",settings:"الإعدادات",'site-editor':"تعديل الموقع"};
document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>showSection(b.dataset.section));
function openDashboardDrawer(){const s=qs('sidebar');if(s){s.classList.add('open');s.style.display='block'}qs('drawerBackdrop')?.classList.add('show')}
function closeDashboardDrawer(){const s=qs('sidebar');if(s){s.classList.remove('open');if(innerWidth<651)s.style.display='none'}qs('drawerBackdrop')?.classList.remove('show')}
function renderSection(id){
  if(!document.getElementById(id)) id='home';
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.section===id));
  document.getElementById('pageTitle').textContent=titles[id]||id;
  document.body.dataset.currentSection=id;
  if(innerWidth<651)closeDashboardDrawer();
}
function showSection(id, push=true){
  if(!document.getElementById(id)) id='home';
  const current=document.body.dataset.currentSection||'home';
  renderSection(id);
  if(push && current!==id){
    history.pushState({eloraDashboard:true,section:id},'', '#'+id);
  }
}
(function initDashboardNavigation(){
  const hash=(location.hash||'').replace('#','');
  const initial=document.getElementById(hash)?hash:'home';
  history.replaceState({eloraDashboard:true,section:initial},'', '#'+initial);
  renderSection(initial);
  window.addEventListener('popstate',()=>{
    const state=history.state;
    const id=state&&state.eloraDashboard?state.section:'home';
    renderSection(id||'home');
  });
})();
async function dashboardLogin(){
  const sb=window.eloraSupabase;if(!sb)return;
  const email=document.getElementById('dashEmail').value.trim(),password=document.getElementById('dashPassword').value;
  const err=document.getElementById('dashAuthError');err.textContent='';
  if(!email||!password){err.textContent='اكتبي البريد وكلمة المرور';return;}
  const r=await sb.auth.signInWithPassword({email,password});
  if(r.error){err.textContent='بيانات الدخول غير صحيحة أو الحساب غير مفعّل';return;}
  document.getElementById('dashboardAuth').hidden=true;
  const emailEl=document.getElementById('adminEmail');if(emailEl)emailEl.textContent=r.data.user?.email||'مدير المتجر';
  loadData();
  setTimeout(()=>{loadShipping();loadVisualState();},300);
}
async function dashboardLogout(){const sb=window.eloraSupabase;if(sb)await sb.auth.signOut();location.reload();}
async function load(){
  const sb=window.eloraSupabase;
  if(!sb){document.getElementById('connection').textContent='لم يتم العثور على eloraSupabase. ضع نفس ملف supabase-config.js المستخدم مع المتجر.';return;}
  const session=await sb.auth.getSession();
  if(!session.data.session){document.getElementById('dashboardAuth').hidden=false;return;}
  document.getElementById('dashboardAuth').hidden=true;
  const emailEl=document.getElementById('adminEmail');if(emailEl)emailEl.textContent=session.data.session.user?.email||'مدير المتجر';
  loadData();
}
function qs(id){return document.getElementById(id)}
function openDashModal(id){qs(id)?.classList.add('show')}function closeDashModal(id){qs(id)?.classList.remove('show')}
function toggleDarkMode(){const on=!document.body.classList.contains('dark');document.body.classList.toggle('dark',on);localStorage.setItem('elora_dashboard_dark',on?'1':'0');updateThemeButton();syncThemeMeta()}
function updateThemeButton(){const b=qs('themeToggle');if(!b)return;const dark=document.body.classList.contains('dark');b.innerHTML=dark?'<i class="fa-solid fa-sun"></i><span>الوضع الفاتح</span>':'<i class="fa-solid fa-moon"></i><span>الوضع الداكن</span>';const h=qs('healthTheme');if(h)h.textContent=dark?'داكن':'فاتح'}
function syncThemeMeta(){const m=qs('dashboardThemeColor');if(m)m.setAttribute('content',document.body.classList.contains('dark')?'#111016':'#f8f7fa')}
(function(){const saved=localStorage.getItem('elora_dashboard_dark');const useDark=saved==='1'||(saved===null&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);if(useDark)document.body.classList.add('dark');updateThemeButton();syncThemeMeta()})()
async function loadAllAdminData(){await Promise.all([loadCategories(),loadOffers(),loadBanners(),loadShipping(),loadSettings(),loadCustomers(),loadPrimeSubscriptions()]);}
async function loadCategories(){const r=await window.eloraSupabase.from('categories').select('*').order('sort_order',{ascending:true});if(!r.error)categories=r.data||[];renderCategories();populateProductCategoryControls()}
function renderCategories(){const el=qs('categoriesTable');if(!el)return;el.innerHTML=categories.length?categories.map(c=>`<tr><td>${escDash(c.name)}</td><td>${escDash(c.slug||'—')}</td><td>${escDash(c.sort_order??0)}</td><td><span class="status ${c.active?'done':'cancel'}">${c.active?'مفعّل':'متوقف'}</span></td><td class="table-actions"><button class="btn light sm" onclick='openCategoryForm(${JSON.stringify(c.id)})'>تعديل</button></td></tr>`).join(''):'<tr><td colspan="5" class="empty">لا توجد أقسام.</td></tr>'}
function openCategoryForm(c=null){editingCategoryId=c?.id||c||null;const x=typeof c==='object'?c:categories.find(v=>String(v.id)===String(c));qs('categoryEditor').hidden=false;qs('categoryEditorTitle').textContent=x?'تعديل قسم':'إضافة قسم';qs('catName').value=x?.name||'';qs('catSlug').value=x?.slug||'';qs('catSlugPreview').value=x?.slug||'';qs('catImage').value=x?.image||'';qs('catSort').value=x?.sort_order??0;qs('catActive').value=String(x?.active!==false);qs('catDeleteBtn').hidden=!x;setImagePreview('catImagePreview',x?.image)}
function closeCategoryForm(){qs('categoryEditor').hidden=true;editingCategoryId=null}
async function saveCategory(){if(!requirePermission(editingCategoryId?'categories.edit':'categories.manage'))return;const name=qs('catName').value.trim();if(!name)return alert('اكتبي اسم القسم');const slug=qs('catSlug').value.trim()||makeSlug(name);qs('catSlug').value=slug;qs('catSlugPreview').value=slug;const imageFile=qs('catImageFile')?.files?.[0];let image=qs('catImage').value.trim()||null;try{if(imageFile)image=await uploadImageToSupabase(imageFile,'categories');const payload={name,slug,image,sort_order:Number(qs('catSort').value||0),active:qs('catActive').value==='true'};const r=editingCategoryId?await window.eloraSupabase.from('categories').update(payload).eq('id',editingCategoryId):await window.eloraSupabase.from('categories').insert([payload]);if(r.error)throw r.error;await loadCategories();closeCategoryForm()}catch(e){alert('تعذر حفظ القسم: '+(e.message||'خطأ غير معروف'))}}
async function deleteCategory(){if(!editingCategoryId||!requirePermission('categories.manage')||!confirm('حذف القسم؟'))return;const r=await window.eloraSupabase.from('categories').delete().eq('id',editingCategoryId);if(r.error)return alert('تعذر حذف القسم: '+r.error.message);await loadCategories();closeCategoryForm()}
async function loadOffers(){const r=await window.eloraSupabase.from('offers').select('*').order('created_at',{ascending:false});if(!r.error)offers=r.data||[];renderOffers()}
function renderOffers(){const el=qs('offersTable');if(!el)return;el.innerHTML=offers.length?offers.map(o=>`<tr><td>${escDash(o.title)}</td><td>${Number(o.discount||0)}%</td><td>${couponDate(o.starts_at)} → ${couponDate(o.ends_at)}</td><td><span class="status ${o.active?'done':'cancel'}">${o.active?'مفعّل':'متوقف'}</span></td><td><button class="btn light sm" onclick='openOfferForm(${JSON.stringify(o.id)})'>تعديل</button></td></tr>`).join(''):'<tr><td colspan="5" class="empty">لا توجد عروض.</td></tr>'}
function openOfferForm(id=null){const x=typeof id==='object'?id:offers.find(v=>String(v.id)===String(id));editingOfferId=x?.id||null;qs('offerEditor').hidden=false;qs('offerEditorTitle').textContent=x?'تعديل عرض':'إضافة عرض';qs('offerTitle').value=x?.title||'';qs('offerDiscount').value=x?.discount??0;qs('offerDescription').value=x?.description||'';qs('offerImage').value=x?.image||'';qs('offerStart').value=x?.starts_at?new Date(x.starts_at).toISOString().slice(0,16):'';qs('offerEnd').value=x?.ends_at?new Date(x.ends_at).toISOString().slice(0,16):'';qs('offerActive').value=String(x?.active!==false);qs('offerDeleteBtn').hidden=!x;setImagePreview('offerImagePreview',x?.image)}
function closeOfferForm(){qs('offerEditor').hidden=true;editingOfferId=null}
async function saveOffer(){if(!requirePermission('offers.manage'))return;const title=qs('offerTitle').value.trim();if(!title)return alert('اكتبي عنوان العرض');let image=qs('offerImage').value.trim()||null;try{const f=qs('offerImageFile')?.files?.[0];if(f)image=await uploadImageToSupabase(f,'offers');const payload={title,discount:Number(qs('offerDiscount').value||0),description:qs('offerDescription').value.trim()||null,image,starts_at:qs('offerStart').value?new Date(qs('offerStart').value).toISOString():null,ends_at:qs('offerEnd').value?new Date(qs('offerEnd').value).toISOString():null,active:qs('offerActive').value==='true'};const r=editingOfferId?await window.eloraSupabase.from('offers').update(payload).eq('id',editingOfferId):await window.eloraSupabase.from('offers').insert([payload]);if(r.error)throw r.error;await loadOffers();closeOfferForm()}catch(e){alert('تعذر حفظ العرض: '+(e.message||'خطأ غير معروف'))}}
async function deleteOffer(){if(!editingOfferId||!requirePermission('offers.manage')||!confirm('حذف العرض؟'))return;const r=await window.eloraSupabase.from('offers').delete().eq('id',editingOfferId);if(r.error)return alert('تعذر حذف العرض: '+r.error.message);await loadOffers();closeOfferForm()}
async function loadBanners(){const r=await window.eloraSupabase.from('banners').select('*').order('sort_order',{ascending:true});if(!r.error)banners=r.data||[];renderBanners()}
function renderBanners(){const el=qs('bannersTable');if(!el)return;el.innerHTML=banners.length?banners.map(b=>`<tr><td>${escDash(b.title||'—')}</td><td>${b.image?'<img src="'+escDash(b.image)+'" style="width:70px;height:38px;object-fit:cover;border-radius:8px">':'—'}</td><td>${b.sort_order??0}</td><td><span class="status ${b.active?'done':'cancel'}">${b.active?'مفعّل':'متوقف'}</span></td><td><button class="btn light sm" onclick='openBannerForm(${JSON.stringify(b.id)})'>تعديل</button></td></tr>`).join(''):'<tr><td colspan="5" class="empty">لا توجد بنرات.</td></tr>'}
function openBannerForm(id=null){const x=typeof id==='object'?id:banners.find(v=>String(v.id)===String(id));editingBannerId=x?.id||null;qs('bannerEditor').hidden=false;qs('bannerEditorTitle').textContent=x?'تعديل بنر':'إضافة بنر';qs('bannerTitle').value=x?.title||'';qs('bannerSubtitle').value=x?.subtitle||'';qs('bannerImage').value=x?.image||'';qs('bannerButtonText').value=x?.button_text||'';qs('bannerButtonAction').value=x?.button_action||'';qs('bannerSort').value=x?.sort_order??0;qs('bannerActive').value=String(x?.active!==false);qs('bannerDeleteBtn').hidden=!x;setImagePreview('bannerImagePreview',x?.image)}
function closeBannerForm(){qs('bannerEditor').hidden=true;editingBannerId=null}
async function saveBanner(){if(!requirePermission('site.hero'))return;let image=qs('bannerImage').value.trim()||null;try{const f=qs('bannerImageFile')?.files?.[0];if(f)image=await uploadImageToSupabase(f,'banners');const payload={title:qs('bannerTitle').value.trim()||null,subtitle:qs('bannerSubtitle').value.trim()||null,image,button_text:qs('bannerButtonText').value.trim()||null,button_action:qs('bannerButtonAction').value.trim()||null,sort_order:Number(qs('bannerSort').value||0),active:qs('bannerActive').value==='true'};const r=editingBannerId?await window.eloraSupabase.from('banners').update(payload).eq('id',editingBannerId):await window.eloraSupabase.from('banners').insert([payload]);if(r.error)throw r.error;await loadBanners();closeBannerForm()}catch(e){alert('تعذر حفظ البنر: '+(e.message||'خطأ غير معروف'))}}
async function deleteBanner(){if(!editingBannerId||!requirePermission('site.hero')||!confirm('حذف البنر؟'))return;const r=await window.eloraSupabase.from('banners').delete().eq('id',editingBannerId);if(r.error)return alert('تعذر حذف البنر: '+r.error.message);await loadBanners();closeBannerForm()}
const DEFAULT_ELORA_GOVERNORATES=['القاهرة','الجيزة','الإسكندرية','القليوبية','الدقهلية','الشرقية','الغربية','المنوفية','البحيرة','كفر الشيخ','دمياط','بورسعيد','الإسماعيلية','السويس','الفيوم','بني سويف','المنيا','أسيوط','سوهاج','قنا','الأقصر','أسوان','مطروح','الوادي الجديد','شمال سيناء','جنوب سيناء','البحر الأحمر'];
const ELORA_SHIPPING_CATALOG={"القاهرة":["مدينة نصر","مصر الجديدة","المعادي","حلوان","شبرا","الساحل","الزيتون","عين شمس","المطرية","النزهة","التجمع","المقطم","المرج","البساتين","دار السلام","وسط القاهرة","غرب مدينة نصر","شرق مدينة نصر","السلام أول","السلام ثان","منشأة ناصر","الوايلي","بولاق","غرب القاهرة","عابدين","الأزبكية","الموسكي","باب الشعرية","مصر القديمة","الخليفة","السيدة زينب","التبين","المعصرة","طرة","15 مايو","الزاوية الحمراء","حدائق القبة","روض الفرج","الشرابية","الأميرية","القاهرة الجديدة","التجمع الأول","التجمع الخامس","مدينتي","الشروق","بدر"],"الجيزة":["الجيزة","الدقي","العجوزة","الهرم","بولاق الدكرور","العمرانية","إمبابة","الوراق","كرداسة","أوسيم","منشأة القناطر","أبو النمرس","الحوامدية","البدرشين","العياط","الصف","أطفيح","6 أكتوبر","الشيخ زايد"],"الإسكندرية":["المنتزه أول","المنتزه ثان","شرق","وسط","غرب","الجمرك","العجمي","العامرية أول","العامرية ثان","برج العرب"],"القليوبية":["بنها","شبرا الخيمة","قليوب","القناطر الخيرية","الخانكة","الخصوص","شبين القناطر","طوخ","كفر شكر","العبور"],"الدقهلية":["المنصورة","طلخا","ميت غمر","أجا","السنبلاوين","دكرنس","منية النصر","الجمالية","المطرية","بلقاس","شربين","نبروه","تمي الأمديد","بني عبيد","ميت سلسيل","محلة دمنة"],"الشرقية":["الزقازيق","بلبيس","منيا القمح","فاقوس","أبو كبير","ههيا","مشتول السوق","أبو حماد","ديرب نجم","كفر صقر","الحسينية","صان الحجر","الإبراهيمية","القنايات","أولاد صقر"],"الغربية":["طنطا","المحلة الكبرى","كفر الزيات","زفتى","السنطة","سمنود","قطور","بسيون"],"المنوفية":["شبين الكوم","منوف","السادات","أشمون","الباجور","قويسنا","بركة السبع","تلا","الشهداء"],"البحيرة":["دمنهور","كفر الدوار","رشيد","إدكو","أبو المطامير","أبو حمص","حوش عيسى","الدلنجات","المحمودية","إيتاي البارود","شبراخيت","كوم حمادة","بدر","وادي النطرون","النوبارية الجديدة","الرحمانية"],"كفر الشيخ":["كفر الشيخ","دسوق","فوه","مطوبس","بلطيم","الحامول","بيلا","سيدي سالم","قلين","الرياض","البرلس"],"دمياط":["دمياط","دمياط الجديدة","رأس البر","فارسكور","الزرقا","كفر سعد","كفر البطيخ","السرو"],"بورسعيد":["حي الشرق","حي العرب","حي المناخ","حي الضواحي","حي الزهور","حي الجنوب"],"الإسماعيلية":["الإسماعيلية","فايد","القنطرة شرق","القنطرة غرب","التل الكبير","أبو صوير","القصاصين الجديدة"],"السويس":["حي السويس","حي الأربعين","حي عتاقة","حي فيصل","حي الجناين"],"الفيوم":["الفيوم","سنورس","إطسا","طامية","أبشواي","يوسف الصديق"],"بني سويف":["بني سويف","الواسطى","ناصر","إهناسيا","ببا","الفشن","سمسطا"],"المنيا":["المنيا","ملوي","سمالوط","أبو قرقاص","مغاغة","بني مزار","مطاي","العدوة","دير مواس"],"أسيوط":["أسيوط","ديروط","القوصية","منفلوط","أبنوب","الفتح","ساحل سليم","البداري","صدفا","الغنايم","أبو تيج"],"سوهاج":["سوهاج","أخميم","جرجا","طهطا","المراغة","البلينا","المنشأة","جهينة","ساقلتة","دار السلام"],"قنا":["قنا","نجع حمادي","دشنا","قفط","قوص","نقادة","أبو تشت","فرشوط","الوقف"],"الأقصر":["الأقصر","الأقصر الجديدة","إسنا","أرمنت","الطود","البياضية","القرنة"],"أسوان":["أسوان","دراو","كوم أمبو","نصر النوبة","إدفو","أبو سمبل السياحية"],"مطروح":["مرسى مطروح","الحمام","العلمين","الضبعة","النجيلة","سيدي براني","السلوم","سيوة"],"الوادي الجديد":["الخارجة","الداخلة","الفرافرة","باريس","بلاط"],"شمال سيناء":["العريش","بئر العبد","الشيخ زويد","رفح","الحسنة","نخل"],"جنوب سيناء":["الطور","شرم الشيخ","دهب","نويبع","طابا","سانت كاترين","رأس سدر","أبو زنيمة","أبو رديس"],"البحر الأحمر":["الغردقة","رأس غارب","سفاجا","القصير","مرسى علم","الشلاتين","حلايب"]};
let shippingGovernorates=[];
let shippingGovernoratesTableReady=true;
let selectedShippingGovernorate='';
let selectedShippingCenter='';
function shippingGov(name){return shippingGovernorates.find(x=>x.governorate===name)||null}
function shippingCatalogRows(){
  const rows=[];
  Object.entries(ELORA_SHIPPING_CATALOG).forEach(([governorate,centers])=>{
    centers.forEach(center=>rows.push({id:`local:${governorate}:${center}`,governorate,center,price:0,active:true,_catalog:true}));
  });
  return rows;
}
function mergeShippingCenters(dbRows){
  const map=new Map();
  shippingCatalogRows().forEach(x=>map.set(`${x.governorate}||${x.center}`,x));
  (dbRows||[]).forEach(x=>map.set(`${x.governorate}||${x.center}`,x));
  return Array.from(map.values());
}
async function loadShipping(){
  const sb=window.eloraSupabase;
  shippingGovernoratesTableReady=true;
  const catalogGovs=DEFAULT_ELORA_GOVERNORATES.map(governorate=>({governorate,price:0,centers_enabled:true,active:true,_fallback:true}));
  if(!sb){
    shippingGovernorates=catalogGovs;
    shippingCenters=shippingCatalogRows();
    if(!selectedShippingGovernorate)selectedShippingGovernorate=shippingGovernorates[0]?.governorate||'';
    renderShippingGovernorates();selectShippingGovernorate(selectedShippingGovernorate,false);renderShipping();return;
  }
  const [g,c]=await Promise.all([
    sb.from('shipping_governorates').select('*'),
    sb.from('shipping_centers').select('*')
  ]);
  if(g.error){
    shippingGovernoratesTableReady=false;
    shippingGovernorates=catalogGovs;
  }else{
    const rows=g.data||[];
    shippingGovernorates=DEFAULT_ELORA_GOVERNORATES.map(name=>rows.find(x=>x.governorate===name)||({governorate:name,price:0,centers_enabled:true,active:true,_fallback:true}));
    rows.filter(x=>!DEFAULT_ELORA_GOVERNORATES.includes(x.governorate)).forEach(x=>shippingGovernorates.push(x));
  }
  shippingCenters=mergeShippingCenters(c.error?[]:(c.data||[]));
  if(!selectedShippingGovernorate||!shippingGov(selectedShippingGovernorate))selectedShippingGovernorate=shippingGovernorates[0]?.governorate||'';
  renderShippingGovernorates();selectShippingGovernorate(selectedShippingGovernorate,false);renderShipping();
}
function shippingGovOrder(name){const i=DEFAULT_ELORA_GOVERNORATES.indexOf(name);return i<0?999:i;}
function renderShippingGovernorates(){
  const q=(qs('shippingGovSearch')?.value||'').trim().toLowerCase();
  const el=qs('shippingGovernoratesCards'); if(!el)return;
  const arr=shippingGovernorates.filter(x=>String(x.governorate||'').toLowerCase().includes(q)).sort((a,b)=>shippingGovOrder(a.governorate)-shippingGovOrder(b.governorate)||String(a.governorate).localeCompare(String(b.governorate),'ar'));
  el.innerHTML=arr.length?arr.map(x=>{
    const count=shippingCenters.filter(c=>c.governorate===x.governorate).length;
    const selected=x.governorate===selectedShippingGovernorate;
    return `<button type="button" class="shipping-gov-card ${selected?'selected':''}" onclick="selectShippingGovernorate(${JSON.stringify(x.governorate)})" aria-pressed="${selected}">
      <div class="gov-top"><strong>${escDash(x.governorate)}</strong><span class="status ${x.active!==false?'done':'cancel'}">${x.active!==false?'مفعّلة':'متوقفة'}</span></div>
      <div class="gov-meta"><span>${money(x.price||0)} للمحافظة</span><span>${count} مركز</span></div>
    </button>`;
  }).join(''):'<div class="empty">لا توجد محافظة مطابقة للبحث.</div>';
  const total=shippingGovernorates.length,active=shippingGovernorates.filter(x=>x.active!==false).length,centers=shippingCenters.length;
  if(qs('shippingSummary'))qs('shippingSummary').innerHTML=`<div class="shipping-stat"><span>المحافظات</span><strong>${total}</strong></div><div class="shipping-stat"><span>المفعّلة</span><strong>${active}</strong></div><div class="shipping-stat"><span>إجمالي مناطق التوصيل</span><strong>${centers}</strong></div>`;
}
function selectShippingGovernorate(name,render=true){
  selectedShippingGovernorate=name||''; selectedShippingCenter='';
  const g=shippingGov(selectedShippingGovernorate);
  const govSel=qs('shipGovSelect');
  if(govSel){
    govSel.innerHTML=shippingGovernorates.map(x=>`<option value="${safeText(x.governorate)}">${escDash(x.governorate)}</option>`).join('');
    govSel.value=selectedShippingGovernorate;
  }
  const centerSel=qs('shipCenterSelect');
  const centers=shippingCenters.filter(x=>x.governorate===selectedShippingGovernorate).sort((a,b)=>String(a.center||'').localeCompare(String(b.center||''),'ar'));
  if(centerSel){
    centerSel.disabled=!g||g.centers_enabled===false;
    centerSel.innerHTML=`<option value="">بدون مركز — السعر على المحافظة بالكامل</option>`+centers.map(x=>`<option value="${safeText(String(x.id))}">${escDash(x.center)} — ${money(x.price||0)}</option>`).join('');
    centerSel.value='';
  }
  qs('shippingEditorTitle').textContent=g?.governorate||'اختاري محافظة';
  qs('shippingEditPrice').value=g?.price??0;
  qs('shipGovActive').value=String(g?.active!==false);
  qs('shipGovCenters').value=String(g?.centers_enabled!==false);
  qs('shippingEffectivePrice').textContent=money(g?.price||0);
  qs('shippingScopeBadge').textContent='سعر المحافظة';
  qs('shippingScopeHelp').textContent='بدون مركز: السعر يطبق على المحافظة بالكامل. عند اختيار مركز، يصبح السعر خاصًا بهذا المركز فقط.';
  if(render)renderShippingGovernorates();
}
function selectShippingCenter(id){
  selectedShippingCenter=id||'';
  const g=shippingGov(selectedShippingGovernorate);
  if(!id){selectShippingGovernorate(selectedShippingGovernorate);return;}
  const c=shippingCenters.find(x=>String(x.id)===String(id)); if(!c)return;
  qs('shippingEditPrice').value=c.price??0;
  qs('shippingEffectivePrice').textContent=money(c.price||0);
  qs('shippingScopeBadge').textContent='سعر مركز محدد';
  qs('shippingScopeHelp').textContent='السعر هنا خاص بالمركز المحدد فقط. إذا لم يتم اختيار مركز، يعود التطبيق لسعر المحافظة.';
  qs('shippingEditorTitle').textContent=`${g?.governorate||''} — ${c.center||''}`;
}
async function saveShippingSelection(){
  if(!requirePermission('shipping.manage'))return;
  const sb=window.eloraSupabase;if(!sb)return alert('Supabase غير متصل');
  const price=Number(qs('shippingEditPrice').value||0);const msg=qs('shippingEditorMessage');let r;
  if(selectedShippingCenter){
    const c=shippingCenters.find(x=>String(x.id)===String(selectedShippingCenter));
    const payload={governorate:c?.governorate||selectedShippingGovernorate,center:c?.center||'',price,active:true};
    if(c?._catalog){
      r=await sb.from('shipping_centers').upsert(payload,{onConflict:'governorate,center'});
    }else{
      r=await sb.from('shipping_centers').update({price,active:true}).eq('id',selectedShippingCenter);
    }
  }else{
    if(!shippingGovernoratesTableReady)return alert('شغّلي Migration الشحن في Supabase أولًا.');
    r=await sb.from('shipping_governorates').upsert({governorate:selectedShippingGovernorate,price,centers_enabled:qs('shipGovCenters').value==='true',active:qs('shipGovActive').value==='true',updated_at:new Date().toISOString()},{onConflict:'governorate'});
  }
  if(r.error){if(msg){msg.className='bulk-result err';msg.textContent='تعذر الحفظ: '+r.error.message;}else alert('تعذر الحفظ: '+r.error.message);return;}
  if(msg){msg.className='bulk-result ok';msg.textContent=selectedShippingCenter?'تم حفظ سعر المركز بنجاح.':'تم حفظ سعر المحافظة وسيطبق على المحافظة بالكامل عند عدم اختيار مركز.';}
  await loadShipping();
}
function renderShipping(){
  const q=(qs('shippingSearch')?.value||'').toLowerCase();const el=qs('shippingTable');
  const arr=shippingCenters.filter(x=>x.governorate===selectedShippingGovernorate&&(String(x.governorate)+' '+String(x.center)).toLowerCase().includes(q)).sort((a,b)=>String(a.center||'').localeCompare(String(b.center||''),'ar'));
  el.innerHTML=arr.length?arr.map(x=>`<tr><td>${escDash(x.governorate)}</td><td>${escDash(x.center)}</td><td>${money(x.price)}</td><td><span class="status ${x.active?'done':'cancel'}">${x.active?'مفعّل':'متوقف'}</span></td><td><button class="btn light sm" onclick='selectShippingCenter(${JSON.stringify(String(x.id))})'>تعديل السعر</button></td></tr>`).join(''):`<tr><td colspan="5" class="empty">لا توجد مراكز لهذه المحافظة.</td></tr>`;
}
function openShippingForm(id=null){const x=typeof id==='object'?id:shippingCenters.find(v=>String(v.id)===String(id));editingShippingId=x?.id||null;qs('shippingEditor').hidden=false;qs('shippingEditorTitleLegacy').textContent=x?'تعديل مركز':'إضافة مركز';qs('shipGovernorate').value=x?.governorate||selectedShippingGovernorate||'';qs('shipCenter').value=x?.center||'';qs('shipPrice').value=x?.price??0;qs('shipActive').value=String(x?.active!==false);qs('shipDeleteBtn').hidden=!x}
function closeShippingForm(){qs('shippingEditor').hidden=true;editingShippingId=null}
async function saveShipping(){if(!requirePermission('shipping.manage'))return;const payload={governorate:qs('shipGovernorate').value.trim(),center:qs('shipCenter').value.trim(),price:Number(qs('shipPrice').value||0),active:qs('shipActive').value==='true'};if(!payload.governorate||!payload.center)return alert('اكتبي المحافظة والمركز');const r=editingShippingId?await window.eloraSupabase.from('shipping_centers').update(payload).eq('id',editingShippingId):await window.eloraSupabase.from('shipping_centers').insert([payload]);if(r.error)return alert('تعذر حفظ الشحن: '+r.error.message);await loadShipping();closeShippingForm()}
async function deleteShipping(){if(!editingShippingId||!requirePermission('shipping.manage')||!confirm('حذف مركز الشحن؟'))return;const r=await window.eloraSupabase.from('shipping_centers').delete().eq('id',editingShippingId);if(r.error)return alert('تعذر حذف المركز: '+r.error.message);await loadShipping();closeShippingForm()}
async function loadCustomers(){const r=await window.eloraSupabase.rpc('admin_list_customers');if(!r.error)customers=r.data||[];renderCustomers();qs('customersCount').textContent=customers.length}
function renderCustomers(){const q=(qs('customerSearch')?.value||'').toLowerCase();const el=qs('customersTable');const arr=customers.filter(c=>String(c.email||'').toLowerCase().includes(q));el.innerHTML=arr.length?arr.map(c=>`<tr><td>${escDash(c.email||'—')}</td><td>${c.created_at?new Date(c.created_at).toLocaleDateString('ar-EG'):'—'}</td><td>${c.last_sign_in_at?new Date(c.last_sign_in_at).toLocaleDateString('ar-EG'):'—'}</td><td>${c.prime_active?'<span class="status done">مفعّل</span>':'<span class="status">غير مفعّل</span>'}</td></tr>`).join(''):'<tr><td colspan="4" class="empty">لا توجد حسابات.</td></tr>'}
async function loadPrimeSubscriptions(){const r=await window.eloraSupabase.rpc('admin_list_prime_subscriptions');if(!r.error)primeSubscriptions=r.data||[];const el=qs('primeSubscriptionsTable');if(!el)return;el.innerHTML=primeSubscriptions.length?primeSubscriptions.map(x=>`<tr><td>${escDash(x.email||x.user_id||'—')}</td><td>${x.started_at?new Date(x.started_at).toLocaleDateString('ar-EG'):'—'}</td><td>${x.expires_at?new Date(x.expires_at).toLocaleDateString('ar-EG'):'—'}</td><td><span class="status ${x.active&&new Date(x.expires_at)>new Date()?'done':'cancel'}">${x.active&&new Date(x.expires_at)>new Date()?'مفعّل':'منتهي'}</span></td></tr>`).join(''):'<tr><td colspan="4" class="empty">لا توجد اشتراكات.</td></tr>'}
async function loadSettings(){const r=await window.eloraSupabase.from('store_settings').select('*').eq('id',1).maybeSingle();if(r.error||!r.data)return;const x=r.data;qs('setStoreName').value=x.store_name||'Elora';qs('setWhatsapp').value=x.whatsapp||'';qs('setInstagram').value=x.instagram||'';qs('setFacebook').value=x.facebook||'';qs('setLogo').value=x.logo||'';qs('payCod').value=String(x.payment_cod!==false);qs('payVodafone').value=String(x.payment_vodafone!==false);qs('payVisa').value=String(x.payment_visa!==false);qs('primePrice').value=x.prime_price??300;qs('primeDiscount').value=x.prime_discount??10;qs('primeFreeOrders').value=x.prime_free_shipping_orders??6}
async function saveStoreSettings(){if(!requirePermission('settings.manage'))return;const payload={id:1,store_name:qs('setStoreName').value.trim()||'Elora',whatsapp:qs('setWhatsapp').value.trim()||null,instagram:qs('setInstagram').value.trim()||null,facebook:qs('setFacebook').value.trim()||null,logo:qs('setLogo').value.trim()||null,updated_at:new Date().toISOString()};const r=await window.eloraSupabase.from('store_settings').upsert(payload,{onConflict:'id'});qs('settingsResult').className=r.error?'bulk-result err':'bulk-result ok';qs('settingsResult').textContent=r.error?'تعذر الحفظ: '+r.error.message:'تم حفظ بيانات المتجر.'}
async function savePaymentSettings(){if(!requirePermission('payments.manage'))return;const payload={id:1,payment_cod:qs('payCod').value==='true',payment_vodafone:qs('payVodafone').value==='true',payment_visa:qs('payVisa').value==='true',updated_at:new Date().toISOString()};const r=await window.eloraSupabase.from('store_settings').upsert(payload,{onConflict:'id'});qs('paymentResult').className=r.error?'bulk-result err':'bulk-result ok';qs('paymentResult').textContent=r.error?'تعذر الحفظ: '+r.error.message:'تم حفظ طرق الدفع.'}
async function savePrimeSettings(){if(!requirePermission('prime.manage'))return;const payload={id:1,prime_price:Number(qs('primePrice').value||300),prime_discount:Number(qs('primeDiscount').value||10),prime_free_shipping_orders:Number(qs('primeFreeOrders').value||6),updated_at:new Date().toISOString()};const r=await window.eloraSupabase.from('store_settings').upsert(payload,{onConflict:'id'});qs('primeSettingsResult').className=r.error?'bulk-result err':'bulk-result ok';qs('primeSettingsResult').textContent=r.error?'تعذر الحفظ: '+r.error.message:'تم حفظ إعدادات Prime.'}

function renderReports(){
  const now=new Date(), start=new Date(now.getFullYear(),now.getMonth(),now.getDate()-6);
  const arr=orders.filter(o=>o.created_at&&new Date(o.created_at)>=start);
  const sales=arr.reduce((n,o)=>n+Number(o.total??o.subtotal??0),0);
  const cost=arr.reduce((n,o)=>{
    if(Number.isFinite(Number(o.cost))) return n+Number(o.cost);
    const items=Array.isArray(o.items)?o.items:[]; return n+items.reduce((x,i)=>x+Number(i.wholesale_price??i.wholesalePrice??i.cost??0)*Number(i.quantity??i.qty??1),0);
  },0);
  const profit=arr.reduce((n,o)=>n+Number(o.profit??0),0) || Math.max(0,sales-cost);
  qs('reportSales').textContent=money(sales); qs('reportCost').textContent=money(cost); qs('reportProfit').textContent=money(profit); qs('reportAov').textContent=money(arr.length?sales/arr.length:0);
  qs('reportOrders').textContent=arr.length; const delivered=arr.filter(o=>o.status==='تم التسليم').length, cancelled=arr.filter(o=>o.status==='ملغي').length;
  qs('reportDelivered').textContent=delivered; qs('reportCancelled').textContent=cancelled; qs('reportCancelRate').textContent=(arr.length?Math.round(cancelled/arr.length*100):0)+'%';
  const days=[]; for(let i=6;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i);const key=d.toISOString().slice(0,10);days.push({d,key,v:arr.filter(o=>o.created_at&&new Date(o.created_at).toISOString().slice(0,10)===key).reduce((n,o)=>n+Number(o.total??o.subtotal??0),0)});}
  const max=Math.max(1,...days.map(x=>x.v)); qs('salesBars').innerHTML=days.map(x=>`<div class="bar" title="${money(x.v)}" style="height:${Math.max(6,Math.round(x.v/max*100))}%"></div>`).join(''); qs('salesLabels').innerHTML=days.map(x=>`<span>${new Date(x.key).toLocaleDateString('ar-EG',{weekday:'short'})}</span>`).join('');
}
function updateHealth(){if(qs('healthProducts'))qs('healthProducts').textContent=products.length.toLocaleString('ar-EG');if(qs('healthOrders'))qs('healthOrders').textContent=orders.length.toLocaleString('ar-EG');if(qs('healthSupabase'))qs('healthSupabase').textContent=window.eloraSupabase?'متصل':'غير متصل';updateThemeButton();}

async function loadData(){populateProductCategoryControls();
  const sb=window.eloraSupabase;
  if(!sb)return;
  document.getElementById('connection').innerHTML='<span style="color:var(--green)">● Supabase متصل</span>';
  try{let r=await sb.from('products').select('*').order('created_at',{ascending:false}).limit(500);if(!r.error)products=r.data||[];renderProductFilters();renderProducts();}
  catch(e){}
  try{let r=await sb.from('orders').select('*').order('created_at',{ascending:false}).limit(100);if(!r.error)orders=r.data||[];renderOrders();renderHome();renderReports();updateHealth();}
  catch(e){renderHome();}
  try{let r=await sb.from('coupons').select('*').order('created_at',{ascending:false}).limit(300);if(!r.error)coupons=r.data||[];renderCoupons();}
  catch(e){renderCoupons();}
  try{await loadAllAdminData()}catch(e){console.warn('admin data:',e)}
  renderReports();updateHealth();
}
function money(v){return Number(v||0).toLocaleString('ar-EG')+' ج.م'}
function couponDate(v){return v?new Date(v).toLocaleDateString('ar-EG'):'—'}
function couponDiscountLabel(c){return c.discount_type==='percent'?`${Number(c.discount_value||0)}%`:`${money(c.discount_value)}`}
function renderCoupons(){
  const el=document.getElementById('couponsTable'); if(!el)return;
  const q=(document.getElementById('couponSearch')?.value||'').toLowerCase();
  const st=document.getElementById('couponStatusFilter')?.value||'';
  const arr=coupons.filter(c=>(!q||String(c.code||'').toLowerCase().includes(q))&&(!st||(st==='active'?c.active:!c.active)));
  el.innerHTML=arr.length?arr.map(c=>`<tr><td><b>${escDash(c.code)}</b></td><td>${couponDiscountLabel(c)}</td><td>${c.free_shipping?'🚚 مجاني':'—'}</td><td>${c.first_order_only?'أول طلب':'كل الطلبات'}</td><td>${money(c.min_order||0)}</td><td>${c.max_discount?money(c.max_discount):'—'}</td><td>${Number(c.usage_limit||0)>0?`${Number(c.used_count||0)} / ${Number(c.usage_limit)}`:`${Number(c.used_count||0)} / ∞`}</td><td>${couponDate(c.starts_at)}</td><td>${couponDate(c.expires_at)}</td><td><span class="status ${c.active?'done':'cancel'}">${c.active?'مفعّل':'متوقف'}</span></td><td><button class="btn light" onclick="editCoupon('${c.id}')">تعديل</button></td></tr>`).join(''):'<tr><td colspan="11" class="empty">لا توجد أكواد خصم.</td></tr>';
}
function escDash(v){return String(v??'').replace(/[&<>'"]/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s]))}
function openCouponForm(c=null){
  editingCouponId=c?.id||null;
  document.getElementById('couponEditor').hidden=false;
  document.getElementById('couponEditorTitle').textContent=editingCouponId?'تعديل كود الخصم':'إضافة كود خصم';
  document.getElementById('couponCodeAdmin').value=c?.code||'';
  document.getElementById('couponTypeAdmin').value=c?.discount_type||'percent';
  document.getElementById('couponValueAdmin').value=c?.discount_value??'';
  document.getElementById('couponFreeShippingAdmin').checked=!!c?.free_shipping;
  if(document.getElementById('couponFirstOrderAdmin'))document.getElementById('couponFirstOrderAdmin').checked=!!c?.first_order_only;
  document.getElementById('couponMinAdmin').value=c?.min_order??0;
  document.getElementById('couponMaxAdmin').value=c?.max_discount??'';
  document.getElementById('couponLimitAdmin').value=c?.usage_limit??'';
  document.getElementById('couponStartAdmin').value=c?.starts_at?new Date(c.starts_at).toISOString().slice(0,16):'';
  document.getElementById('couponEndAdmin').value=c?.expires_at?new Date(c.expires_at).toISOString().slice(0,16):'';
  document.getElementById('couponActiveAdmin').value=String(c?.active!==false);
  document.getElementById('couponDeleteBtn').hidden=!editingCouponId;
  document.getElementById('couponEditor').scrollIntoView({behavior:'smooth',block:'start'});
}
function closeCouponForm(){editingCouponId=null;const e=document.getElementById('couponEditor');if(e)e.hidden=true;}
function editCoupon(id){const c=coupons.find(x=>String(x.id)===String(id));if(c)openCouponForm(c)}
async function saveCoupon(){
  const sb=window.eloraSupabase;if(!sb){alert('Supabase غير متصل');return;}
  const code=document.getElementById('couponCodeAdmin').value.trim().toUpperCase();
  const type=document.getElementById('couponTypeAdmin').value;
  const value=Number(document.getElementById('couponValueAdmin').value||0);
  const min=Number(document.getElementById('couponMinAdmin').value||0);
  const maxRaw=document.getElementById('couponMaxAdmin').value.trim();
  const limitRaw=document.getElementById('couponLimitAdmin').value.trim();
  const starts=document.getElementById('couponStartAdmin').value;
  const ends=document.getElementById('couponEndAdmin').value;
  const freeShipping=document.getElementById('couponFreeShippingAdmin').checked;
  if(!code||(!freeShipping&&value<=0)||value<0){alert(freeShipping?'اكتبي الكود وقيمة الخصم (يمكن أن تكون 0 مع الشحن المجاني).':'اكتبي الكود وقيمة الخصم بشكل صحيح');return;}
  if(type==='percent'&&value>100){alert('النسبة لا يمكن أن تتجاوز 100%');return;}
  if(min<0||(maxRaw&&Number(maxRaw)<0)||(limitRaw&&Number(limitRaw)<0)){alert('تحققي من القيم المدخلة');return;}
  const payload={code,discount_type:type,discount_value:value,free_shipping:freeShipping,first_order_only:!!qs('couponFirstOrderAdmin')?.checked,min_order:min,max_discount:maxRaw?Number(maxRaw):null,usage_limit:limitRaw?Number(limitRaw):null,starts_at:starts?new Date(starts).toISOString():null,expires_at:ends?new Date(ends).toISOString():null,active:document.getElementById('couponActiveAdmin').value==='true'};
  try{
    let r=editingCouponId?await sb.from('coupons').update(payload).eq('id',editingCouponId):await sb.from('coupons').insert([payload]);
    if(r.error)throw r.error;
    alert(editingCouponId?'تم تعديل كود الخصم':'تم إنشاء كود الخصم');
    const rr=await sb.from('coupons').select('*').order('created_at',{ascending:false}).limit(300);coupons=rr.data||[];renderCoupons();closeCouponForm();
  }catch(e){console.error(e);alert('تعذر حفظ الكود: '+(e.message||'خطأ غير معروف'));}
}
async function deleteCoupon(){
  if(!editingCouponId||!confirm('هل تريدين حذف كود الخصم؟'))return;
  const sb=window.eloraSupabase;if(!sb)return;
  const r=await sb.from('coupons').delete().eq('id',editingCouponId);if(r.error){alert('تعذر حذف الكود: '+r.error.message);return;}
  coupons=coupons.filter(c=>String(c.id)!==String(editingCouponId));renderCoupons();closeCouponForm();
}
function renderProductFilters(){const s=document.getElementById('productCategoryFilter');if(!s)return;const current=s.value;const cats=[...new Set(products.map(p=>String(p.category||p.section||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ar'));s.innerHTML='<option value="">كل الأقسام</option>'+cats.map(c=>`<option value="${escDash(c)}">${escDash(c)}</option>`).join('');s.value=current&&cats.includes(current)?current:''}
function renderProducts(){let el=document.getElementById('productsTable');if(!el)return;const q=(document.getElementById('productSearch')?.value||'').trim().toLowerCase();const cat=document.getElementById('productCategoryFilter')?.value||'';const arr=products.filter(p=>{let text=String(p.name||'')+' '+String(p.code||'')+' '+String(p.category||p.section||'');return(!q||text.toLowerCase().includes(q))&&(!cat||String(p.category||p.section||'')===cat)});if(!arr.length){el.innerHTML='<tr><td colspan="8" class="empty">لا توجد منتجات مطابقة.</td></tr>';return}el.innerHTML=arr.map(p=>{const colors=Array.isArray(p.colors)?p.colors.join('، '):(p.colors||'');const sizes=Array.isArray(p.sizes)?p.sizes.join('، '):(p.sizes||'');return `<tr><td>${p.image||p.image_url?'<img loading="lazy" src="'+escDash(p.image||p.image_url)+'" style="width:42px;height:42px;object-fit:cover;border-radius:9px">':'—'}</td><td>${escDash(p.name||p.title||'—')}</td><td>${escDash(p.category||p.section||'—')}</td><td>${money(p.price??p.sale_price)}</td><td>${money(p.wholesale_price??p.wholesalePrice)}</td><td>${escDash(p.code||p.product_code||'—')}</td><td>${escDash(p.stock??p.inventory??'—')}<div style="font-size:10px;color:var(--muted);margin-top:3px">${colors?'ألوان: '+escDash(colors):''}${colors&&sizes?' • ':''}${sizes?'مقاسات: '+escDash(sizes):''}</div></td><td class="table-actions"><button class="btn light sm" onclick='openProductEditorById(${JSON.stringify(String(p.id))})'>تعديل</button><button class="btn danger sm" onclick='deleteProductById(${JSON.stringify(String(p.id))})'>حذف</button></td></tr>`}).join('')}
function openProductEditorById(id){const p=products.find(x=>String(x.id)===String(id));if(p)openProductEditor(p)}
async function deleteProductById(id){if(!requirePermission('products.delete')||!confirm('حذف المنتج نهائيًا؟'))return;const r=await window.eloraSupabase.from('products').delete().eq('id',id);if(r.error){alert('تعذر حذف المنتج: '+r.error.message);return}products=products.filter(p=>String(p.id)!==String(id));renderProducts()}
function exportProductsExcel(){if(!requirePermission('products.export'))return;if(!window.XLSX)return alert('مكوّن Excel غير متاح');const rows=products.map(p=>({'كود المنتج':p.code||'','اسم المنتج':p.name||'','الوصف':p.description||'','الصنف':p.category||'','سعر البيع':p.price??0,'السعر القديم':p.old_price??'','سعر الجملة':p.wholesale_price??'','المخزون':p.stock??0,'الخصم':p.discount??0,'مميز':p.featured?'نعم':'لا','نشط':p.active?'نعم':'لا','الألوان':Array.isArray(p.colors)?p.colors.join('، '):(p.colors||''),'المقاسات':Array.isArray(p.sizes)?p.sizes.join('، '):(p.sizes||''),'الخيارات':p.variants?JSON.stringify(p.variants):'','الصورة':p.image||''}));const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'المنتجات');XLSX.writeFile(wb,'Elora_Products_Export.xlsx')}
async function deleteOrderById(id){if(!requirePermission('orders.delete')||!confirm('حذف الطلب نهائيًا؟'))return;const r=await window.eloraSupabase.from('orders').delete().eq('id',id);if(r.error){alert('تعذر حذف الطلب: '+r.error.message);return}orders=orders.filter(o=>String(o.id)!==String(id));renderOrders();renderHome()}
function renderOrders(){let q=(document.getElementById('orderSearch')?.value||'').toLowerCase(), st=document.getElementById('orderStatus')?.value||'';let arr=orders.filter(o=>{let text=JSON.stringify(o).toLowerCase();return(!q||text.includes(q))&&(!st||o.status===st)});let el=document.getElementById('ordersTable');el.innerHTML=arr.length?arr.map(o=>`<tr><td data-label="الطلب"><b>#${o.order_number||o.id||'—'}</b></td><td data-label="العميل">${escDash(o.customer_name||o.name||'—')}</td><td data-label="الهاتف">${can('orders.customer_data')?escDash(o.phone||o.customer_phone||'—'):'مخفي'}</td><td data-label="الإجمالي">${money(o.total??o.subtotal)}</td><td data-label="التاريخ">${o.created_at?new Date(o.created_at).toLocaleDateString('ar-EG'):'—'}</td><td data-label="الحالة"><span class="status ${o.status==='تم التسليم'?'done':o.status==='ملغي'?'cancel':'pending'}">${escDash(o.status||'جديد')}</span></td><td data-label="إجراءات" class="table-actions"><button class="btn light sm" onclick='showOrderDetails(${JSON.stringify(String(o.id))})'>التفاصيل</button><button class="btn primary sm" onclick='quickOrderStatus(${JSON.stringify(String(o.id))})'>تغيير الحالة</button><button class="btn danger sm" onclick='deleteOrderById(${JSON.stringify(String(o.id))})'>حذف</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">لا توجد طلبات.</td></tr>'}
async function loadOrders(){const sb=window.eloraSupabase;if(!sb)return;const r=await sb.from('orders').select('*').order('created_at',{ascending:false}).limit(500);if(!r.error)orders=r.data||[];renderOrders();renderHome()}
function showOrderDetails(id){const o=orders.find(x=>String(x.id)===String(id));if(!o)return;const items=Array.isArray(o.items)?o.items:[];const body=qs('orderDetailsBody');body.innerHTML=`<div class="notice"><b>رقم الطلب:</b> #${escDash(o.order_number||o.id)}<br><b>العميل:</b> ${escDash(o.customer_name||'—')}<br><b>الهاتف:</b> ${can('orders.customer_data')?escDash(o.phone||o.customer_phone||'—'):'مخفي'}<br><b>المحافظة:</b> ${escDash(o.governorate||'—')} — <b>المركز:</b> ${escDash(o.center||'—')}<br><b>العنوان:</b> ${can('orders.customer_data')?escDash(o.address||'—'):'مخفي'}<br><b>الدفع:</b> ${escDash(o.payment_method||'—')}<br><b>الحالة:</b> ${escDash(o.status||'جديد')}</div><div class="table-wrap"><table><thead><tr><th>المنتج</th><th>الكود</th><th>لون</th><th>مقاس</th><th>الكمية</th><th>السعر</th></tr></thead><tbody>${items.map(i=>`<tr><td>${escDash(i.name||'—')}</td><td>${escDash(i.code||'—')}</td><td>${escDash(i.color||'—')}</td><td>${escDash(i.size||'—')}</td><td>${escDash(i.quantity??i.qty??1)}</td><td>${money(i.price||0)}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">لا توجد تفاصيل منتجات محفوظة.</td></tr>'}</tbody></table></div><div><b>الإجمالي: ${money(o.total??o.subtotal)}</b>${o.profit!==undefined?' — الربح: '+money(o.profit):''}</div>`;openDashModal('orderModal')}
async function quickOrderStatus(id){if(!requirePermission('orders.edit'))return;const o=orders.find(x=>String(x.id)===String(id));if(!o)return;const statuses=['جديد','قيد التجهيز','تم الشحن','تم التسليم','ملغي'];const current=o.status||'جديد';const body=qs('orderDetailsBody');body.innerHTML=`<div class="notice"><b>الطلب:</b> #${escDash(o.order_number||o.id)}<br><b>العميل:</b> ${escDash(o.customer_name||o.name||'—')}</div><label class="form" style="padding:0">الحالة<select id="orderStatusModalSelect">${statuses.map(x=>`<option ${x===current?'selected':''}>${x}</option>`).join('')}</select></label><button class="btn primary" id="saveOrderStatusModal">حفظ الحالة</button>`;openDashModal('orderModal');qs('saveOrderStatusModal').onclick=async()=>{const status=qs('orderStatusModalSelect').value;const r=await window.eloraSupabase.from('orders').update({status}).eq('id',id);if(r.error){alert('تعذر تغيير الحالة: '+r.error.message);return}o.status=status;closeDashModal('orderModal');renderOrders();renderHome();renderReports()};}
function renderHome(){const now=new Date(),monthStart=new Date(now.getFullYear(),now.getMonth(),1);const monthOrders=orders.filter(o=>o.created_at&&new Date(o.created_at)>=monthStart);qs('ordersCount').textContent=monthOrders.length;const sales=monthOrders.reduce((sum,o)=>sum+Number(o.total??o.subtotal??0),0);qs('sales').textContent=money(sales);const profit=monthOrders.reduce((sum,o)=>sum+Number(o.profit??0),0);qs('profit').textContent=money(profit);qs('recentOrders').innerHTML=orders.slice(0,6).map(o=>`<tr><td>#${escDash(o.order_number||o.id||'—')}</td><td>${escDash(o.customer_name||o.name||'—')}</td><td>${money(o.total??o.subtotal)}</td><td>${escDash(o.payment_method||'—')}</td><td><span class="status pending">${escDash(o.status||'جديد')}</span></td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا توجد طلبات حتى الآن.</td></tr>'}
let bulkRows=[], bulkImageMap=new Map();
function openBulkImport(){const p=document.getElementById('bulkImportPanel');if(p){p.hidden=false;p.scrollIntoView({behavior:'smooth',block:'start'})}}
function closeBulkImport(){const p=document.getElementById('bulkImportPanel');if(p)p.hidden=true}
function normalizeKey(v){return String(v??'').trim().toLowerCase().replace(/\\/g,'/').split('/').pop().replace(/\.[^.]+$/,'')}
function getRowValue(row, keys){for(const k of keys){if(row[k]!==undefined&&row[k]!==null&&String(row[k]).trim()!=='')return row[k]}return ''}
function normalizeProductRow(r){return {name:String(getRowValue(r,['name','اسم المنتج','الاسم','product_name'])).trim(),description:String(getRowValue(r,['description','الوصف','وصف'])).trim(),category:String(getRowValue(r,['category','section','القسم'])).trim(),price:Number(getRowValue(r,['price','sale_price','سعر البيع','السعر'])||0),old_price:Number(getRowValue(r,['old_price','oldPrice','السعر القديم'])||0),wholesale_price:Number(getRowValue(r,['wholesale_price','wholesalePrice','سعر الجملة'])||0),code:String(getRowValue(r,['code','product_code','كود المنتج','الكود'])).trim(),stock:parseInt(getRowValue(r,['stock','inventory','المخزون','الكمية'])||0,10)||0,discount:Number(getRowValue(r,['discount','الخصم'])||0),featured:Boolean(getRowValue(r,['featured','مميز'])===true||['1','true','yes','نعم'].includes(String(getRowValue(r,['featured','مميز'])).toLowerCase())),active:!['0','false','no','لا'].includes(String(getRowValue(r,['active','نشط'])).toLowerCase()),image:String(getRowValue(r,['image','image_url','الصورة','رابط الصورة'])).trim()||null}}
async function previewBulkImport(){const input=document.getElementById('bulkProductsFile'),preview=document.getElementById('bulkPreview'),btn=document.getElementById('bulkImportBtn');bulkRows=[];if(!input?.files?.[0]){preview.textContent='لم يتم اختيار ملف بعد.';btn.disabled=true;return}try{const data=await input.files[0].arrayBuffer();const wb=XLSX.read(data,{type:'array'});const ws=wb.Sheets[wb.SheetNames[0]];const rows=XLSX.utils.sheet_to_json(ws,{defval:''});bulkRows=rows.map(normalizeProductRow).filter(r=>r.name||r.code);const missingCode=bulkRows.filter(r=>!r.code).length;preview.innerHTML=`تم العثور على <b>${bulkRows.length.toLocaleString('ar-EG')}</b> منتج. ${missingCode?`<span style="color:var(--orange)">${missingCode.toLocaleString('ar-EG')} بدون كود.</span>`:'كل المنتجات تحتوي على كود.'}<br>الأعمدة المدعومة: الاسم، الوصف، القسم، السعر، السعر القديم، سعر الجملة، الكود، المخزون، الخصم، مميز، نشط، رابط الصورة.`;btn.disabled=!bulkRows.length}catch(e){preview.textContent='تعذر قراءة ملف Excel/CSV: '+(e.message||'خطأ غير معروف');btn.disabled=true}}
function previewBulkImages(){const files=[...(document.getElementById('bulkImagesFiles')?.files||[])];bulkImageMap=new Map();for(const f of files)bulkImageMap.set(normalizeKey(f.name),f);const preview=document.getElementById('bulkPreview');if(files.length)preview.innerHTML+=(preview.innerHTML?'<br>':'')+`تم اختيار <b>${files.length.toLocaleString('ar-EG')}</b> صورة. المطابقة تكون بالكود أولًا ثم اسم الملف.`}
function imageForRow(row){if(!bulkImageMap.size)return null;return bulkImageMap.get(normalizeKey(row.code))||bulkImageMap.get(normalizeKey(row.name))||null}
function setBulkProgress(pct,text){const wrap=document.getElementById('bulkProgress');wrap.hidden=false;document.getElementById('bulkProgressBar').style.width=pct+'%';document.getElementById('bulkProgressText').textContent=text||pct+'%'}
async function compressImage(file){if(!file||!file.type.startsWith('image/'))return file;try{const bitmap=await createImageBitmap(file);const max=1200;const scale=Math.min(1,max/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));const ctx=canvas.getContext('2d',{alpha:true});ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);const blob=await new Promise(r=>canvas.toBlob(r,'image/webp',0.82));if(!blob)return file;return new File([blob],(normalizeKey(file.name)||'product')+'.webp',{type:'image/webp'})}catch(e){return file}}
function makeSlug(v){return String(v||'').trim().toLowerCase().replace(/\s+/g,'-').replace(/[^\w\u0600-\u06FF-]+/g,'').replace(/-+/g,'-').replace(/^-|-$/g,'')||('section-'+Date.now())}
function setImagePreview(id,url){const el=qs(id);if(!el)return;el.innerHTML=url?`<img src="${escDash(url)}" alt="معاينة">`:''}
function previewUploadedImage(input,previewId){const file=input?.files?.[0];if(!file)return;const u=URL.createObjectURL(file);setImagePreview(previewId,u)}
async function uploadImageToSupabase(file,folder='general'){
  const sb=window.eloraSupabase;if(!sb)throw new Error('Supabase غير متصل');
  if(!file||!file.type?.startsWith('image/'))throw new Error('اختاري ملف صورة صحيح');
  if(file.size>8*1024*1024)throw new Error('حجم الصورة كبير. الحد الأقصى 8MB');
  const compressed=await compressImage(file);const safe=(file.name||'image.jpg').replace(/[^a-zA-Z0-9._-]/g,'_');
  const path=`${folder}/${Date.now()}-${Math.random().toString(36).slice(2,8)}-${safe}`;
  const r=await sb.storage.from('elora-images').upload(path,compressed,{contentType:compressed.type||'image/jpeg',upsert:false});
  if(r.error)throw r.error;
  const pub=sb.storage.from('elora-images').getPublicUrl(path);return pub?.data?.publicUrl||null;
}
async function uploadImageToR2(file,code){const url=(window.ELORA_IMAGE_UPLOAD_URL||'').trim();if(!url)return null;const small=await compressImage(file);const fd=new FormData();fd.append('file',small,small.name);fd.append('code',code||normalizeKey(file.name));const session=await window.eloraSupabase?.auth.getSession();const token=session?.data?.session?.access_token||'';if(!token)throw new Error('انتهت جلسة الدخول');const r=await fetch(url,{method:'POST',headers:{Authorization:'Bearer '+token},body:fd});if(!r.ok)throw new Error('فشل رفع الصورة إلى R2');const j=await r.json();return j.url||j.publicUrl||null}
async function runBulkImport(){const sb=window.eloraSupabase,btn=document.getElementById('bulkImportBtn'),result=document.getElementById('bulkResult');if(!sb){result.className='bulk-result err';result.textContent='Supabase غير متصل.';return}if(!bulkRows.length)return;btn.disabled=true;result.className='bulk-result';result.textContent='';let ok=0,images=0;const batchSize=250;try{for(let start=0;start<bulkRows.length;start+=batchSize){const batch=bulkRows.slice(start,start+batchSize);for(const row of batch){const file=imageForRow(row);if(file){try{const r2=await uploadImageToR2(file,row.code);if(r2){row.image=r2;images++}}catch(e){}}}let r=await sb.from('products').upsert(batch,{onConflict:'code',ignoreDuplicates:false});if(r.error){r=await sb.from('products').insert(batch);if(r.error)throw r.error}ok+=batch.length;setBulkProgress(Math.min(100,Math.round(((start+batch.length)/bulkRows.length)*100)),`تم استيراد ${Math.min(start+batch.length,bulkRows.length).toLocaleString('ar-EG')} من ${bulkRows.length.toLocaleString('ar-EG')}`)}result.className='bulk-result ok';result.innerHTML=`اكتمل الاستيراد: <b>${ok.toLocaleString('ar-EG')}</b> منتج، وتم رفع <b>${images.toLocaleString('ar-EG')}</b> صورة مضغوطة إلى R2.`;const rr=await sb.from('products').select('*').order('created_at',{ascending:false}).limit(500);if(!rr.error)products=rr.data||products;renderProductFilters();renderProducts()}catch(e){result.className='bulk-result err';result.innerHTML=`توقف الاستيراد بعد <b>${ok.toLocaleString('ar-EG')}</b> منتج. السبب: ${escDash(e.message||'خطأ غير معروف')}` }finally{btn.disabled=false}}
function downloadProductTemplate(){const rows=[{code:'EL001',name:'اسم المنتج',description:'وصف المنتج',category:'إكسسوارات',price:250,old_price:300,wholesale_price:150,stock:20,discount:0,featured:true,active:true,image:'EL001.jpg'}];const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Products');XLSX.writeFile(wb,'Elora_Products_Template.xlsx')}

// ===== Staff permissions / real-time access control =====
const PERMISSION_GROUPS={
  'المنتجات':['products.view','products.add','products.edit','products.delete','products.import','products.export','products.view_price','products.view_wholesale','products.edit_price','products.stock','products.options'],
  'الطلبات':['orders.view','orders.edit','orders.delete','orders.customer_data','orders.view_wholesale'],
  'التقارير والأرباح':['reports.sales','reports.profit','reports.wholesale'],
  'الموقع':['site.edit','site.sections','site.hero','site.design','site.css'],
  'الأقسام والعروض والأكواد':['categories.view','categories.manage','offers.view','offers.manage','coupons.view','coupons.manage'],
  'الشحن والدفع':['shipping.view','shipping.manage','payments.view','payments.manage'],
  'Prime والعملاء':['prime.view','prime.manage','prime.manual_grant','customers.view','customers.manage'],
  'الإعدادات والموظفون':['settings.manage','staff.view','staff.manage']
};
const PERMISSION_LABELS={
'products.view':'مشاهدة المنتجات','products.add':'إضافة المنتجات','products.edit':'تعديل المنتجات','products.delete':'حذف المنتجات','products.import':'استيراد Excel/CSV','products.export':'تصدير المنتجات','products.view_price':'مشاهدة سعر البيع','products.view_wholesale':'مشاهدة سعر الجملة','products.edit_price':'تعديل الأسعار','products.stock':'إدارة المخزون','products.options':'الألوان والمقاسات والمتغيرات','orders.view':'مشاهدة الطلبات','orders.edit':'تعديل الطلبات','orders.delete':'حذف الطلبات','orders.customer_data':'بيانات العملاء','orders.view_wholesale':'سعر الجملة في الطلبات','reports.sales':'تقارير المبيعات','reports.profit':'الأرباح','reports.wholesale':'التكلفة وسعر الجملة','site.edit':'تعديل الموقع','site.sections':'الأقسام','site.hero':'السلايدر والبنرات','site.design':'الألوان والتصميم','site.css':'CSS متقدم','offers.view':'مشاهدة العروض','offers.manage':'إدارة العروض','coupons.view':'مشاهدة الأكواد','coupons.manage':'إدارة الأكواد','shipping.view':'مشاهدة الشحن','shipping.manage':'إدارة الشحن','payments.view':'مشاهدة الدفع','payments.manage':'إدارة الدفع','prime.view':'مشاهدة Prime','prime.manage':'إدارة Prime','prime.manual_grant':'تفعيل Prime يدويًا','customers.view':'مشاهدة العملاء','customers.manage':'إدارة العملاء','settings.manage':'إعدادات المتجر','staff.view':'مشاهدة الموظفين','staff.manage':'إدارة الموظفين'};
let currentStaff=[],editingStaffId=null,currentPermissions={};
function defaultStaffPermissions(){const p={};Object.values(PERMISSION_GROUPS).flat().forEach(k=>p[k]=false);['products.view','products.view_price','orders.view','reports.sales','orders.customer_data','customers.view','categories.view','offers.view','coupons.view','shipping.view','payments.view','prime.view'].forEach(k=>p[k]=true);return p}
function isManagerRole(role){return ['owner','admin','manager'].includes(String(role||'').toLowerCase())}
async function getMyStaffProfile(){const sb=window.eloraSupabase;if(!sb)return null;const uid=(await sb.auth.getUser()).data.user?.id;if(!uid)return null;const r=await sb.from('staff_profiles').select('id,role,permissions,active,name,email').eq('id',uid).maybeSingle();if(r.error)return null;return r.data}
async function loadStaffAccess(){const me=await getMyStaffProfile();if(!me){const u=(await window.eloraSupabase.auth.getUser()).data.user; if(u?.email==='ilnemrawi@gmail.com'){currentPermissions=defaultStaffPermissions();Object.keys(currentPermissions).forEach(k=>currentPermissions[k]=true);window.eloraStaff={id:u.id,role:'owner',active:true,permissions:currentPermissions};applyAccess(currentPermissions);return} applyAccess({});return}if(!me.active){await window.eloraSupabase.auth.signOut();location.reload();return}currentPermissions=Object.assign(defaultStaffPermissions(),me.permissions||{});if(isManagerRole(me.role))Object.keys(currentPermissions).forEach(k=>currentPermissions[k]=true);window.eloraStaff={id:me.id,role:me.role,active:me.active,permissions:currentPermissions};applyAccess(currentPermissions);subscribeStaffRealtime(me.id);}
function can(p){return isManagerRole(window.eloraStaff?.role)||!!window.eloraStaff?.permissions?.[p]}
function applyAccess(perms){document.querySelectorAll('[data-permission]').forEach(el=>{const p=el.dataset.permission;el.hidden=!can(p)});const staffNav=document.querySelector('[data-section="staff"]');if(staffNav)staffNav.hidden=!can('staff.manage');const profit=document.querySelector('[data-permission="reports.profit"]');if(profit)profit.hidden=!can('reports.profit');if(!can('staff.manage')&&document.getElementById('staff')?.classList.contains('active'))showSection('home');const wh=can('products.view_wholesale');document.querySelectorAll('[data-wholesale]').forEach(el=>el.hidden=!wh);}
function requirePermission(p){if(can(p))return true;alert('ليس لديك صلاحية لهذا الإجراء.');return false}
function renderPermissionGrid(perms){const box=qs('permissionsGrid');if(!box)return;box.innerHTML=Object.entries(PERMISSION_GROUPS).map(([g,keys])=>`<div class="perm-group">${g}</div>`+keys.map(k=>`<label class="permission-item"><span>${PERMISSION_LABELS[k]||k}</span><input type="checkbox" data-perm="${k}" ${perms[k]?'checked':''}></label>`).join('')).join('')}
function openStaffForm(staff){if(!requirePermission('staff.manage'))return;editingStaffId=staff?.id||null;qs('staffEditor').hidden=false;qs('staffEditorTitle').textContent=staff?'تعديل موظف':'إضافة موظف';qs('staffEmailInput').value=staff?.email||'';qs('staffEmailInput').readOnly=!!staff;qs('staffNameInput').value=staff?.name||'';qs('staffRoleInput').value=staff?.role||'staff';qs('staffActiveInput').checked=staff?.active!==false;qs('staffDeactivateBtn').hidden=!staff;currentPermissions=Object.assign(defaultStaffPermissions(),staff?.permissions||{});renderPermissionGrid(currentPermissions);window.scrollTo({top:document.getElementById('staff').offsetTop,behavior:'smooth'})}
function closeStaffForm(){qs('staffEditor').hidden=true;editingStaffId=null}
async function refreshStaff(){if(!requirePermission('staff.manage'))return;const sb=window.eloraSupabase;if(!sb)return;const r=await sb.from('staff_profiles').select('id,email,name,role,permissions,active,updated_at').order('created_at',{ascending:false});if(r.error){qs('staffTable').innerHTML=`<tr><td colspan="5" class="empty">${escDash(r.error.message)}</td></tr>`;return}currentStaff=r.data||[];renderStaff()}
function renderStaff(){const q=(qs('staffSearch')?.value||'').toLowerCase();const arr=currentStaff.filter(x=>(`${x.email||''} ${x.name||''}`).toLowerCase().includes(q));qs('staffTable').innerHTML=arr.length?arr.map(s=>{const active=s.active!==false;const enabled=Object.entries(s.permissions||{}).filter(([,v])=>v).length;return `<tr><td><b>${escDash(s.name||'بدون اسم')}</b><div style="font-size:10px;color:var(--muted)">${escDash(s.email||'')}</div></td><td>${escDash(s.role||'staff')}</td><td><span class="status ${active?'done':'cancel'}">${active?'مفعّل':'متوقف'}</span></td><td>${isManagerRole(s.role)?'<span class="staff-pill">كل الصلاحيات</span>':`<span class="staff-pill">${enabled} صلاحية</span>`}</td><td><button class="btn light" onclick='openStaffForm(${JSON.stringify(s).replace(/</g,'\u003c')})'>تعديل</button></td></tr>`}).join(''):'<tr><td colspan="5" class="empty">لا يوجد موظفون.</td></tr>'}
async function saveStaff(){if(!requirePermission('staff.manage'))return;const email=qs('staffEmailInput').value.trim();if(!email)return alert('اكتب البريد الإلكتروني');const permissions={};document.querySelectorAll('#permissionsGrid [data-perm]').forEach(i=>permissions[i.dataset.perm]=i.checked);const sb=window.eloraSupabase;const payload={p_email:email,p_name:qs('staffNameInput').value.trim()||null,p_role:qs('staffRoleInput').value,p_permissions:permissions,p_active:qs('staffActiveInput').checked};const out=qs('staffResult');out.textContent='جاري الحفظ...';try{const r=await sb.rpc('admin_upsert_staff_by_email',payload);if(r.error)throw r.error;out.className='bulk-result ok';out.textContent='تم حفظ الموظف والصلاحيات فورًا.';await refreshStaff();closeStaffForm()}catch(e){out.className='bulk-result err';out.textContent='تعذر الحفظ: '+(e.message||'خطأ غير معروف')}}
async function deactivateStaff(){if(!requirePermission('staff.manage')||!editingStaffId)return;const sb=window.eloraSupabase;const r=await sb.rpc('admin_set_staff_active',{p_staff_id:editingStaffId,p_active:false});if(r.error)return alert(r.error.message);await refreshStaff();closeStaffForm()}
function subscribeStaffRealtime(myId){const sb=window.eloraSupabase;if(!sb)return;try{sb.channel('elora-staff-access-'+myId).on('postgres_changes',{event:'UPDATE',schema:'public',table:'staff_profiles',filter:'id=eq.'+myId},payload=>{const row=payload.new||{};if(row.active===false){sb.auth.signOut().then(()=>location.reload());return}currentPermissions=Object.assign(defaultStaffPermissions(),row.permissions||{});if(isManagerRole(row.role))Object.keys(currentPermissions).forEach(k=>currentPermissions[k]=true);window.eloraStaff={id:myId,role:row.role,active:row.active,permissions:currentPermissions};applyAccess(currentPermissions);}).subscribe();setInterval(loadStaffAccess,15000)}catch(e){setInterval(loadStaffAccess,15000)}}

load();
loadStaffAccess().then(refreshStaff);
updateHealth();

// ===== Elora Dashboard V2 =====
let visualState={elements:{},customSections:[],css:''};
let visualSelected=null;
function qs(id){return document.getElementById(id)}
function safeText(v){return String(v??'').replace(/[&<>'"]/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s]))}
function openVisualEditor(){const sec=qs('site-editor');if(!sec)return alert('محرر الموقع غير موجود في هذه النسخة.');showSection('site-editor');sec.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>{sitePreviewReload();},150);}
async function loadVisualState(){const sb=window.eloraSupabase;if(!sb)return;try{const r=await sb.from('site_customizations').select('config').eq('id',1).maybeSingle();if(!r.error&&r.data?.config)visualState=Object.assign({elements:{},customSections:[],css:''},r.data.config);applyVisualStateToFrame()}catch(e){console.warn(e)}}
function frameDoc(){try{return qs('sitePreview')?.contentDocument||null}catch(e){return null}}
function bindFramePicker(){
  const doc=frameDoc();if(!doc||doc.__eloraPickerBound)return;
  doc.__eloraPickerBound=true;
  doc.addEventListener('click',e=>{
    const el=e.target?.closest?.('*'); if(!el)return;
    if(el.closest('a,button,input,textarea,select')) e.preventDefault(); else e.preventDefault();
    e.stopPropagation(); visualSelected=el;
    const sel=makeSelector(el); qs('veSelector').value=sel; qs('selectedSelector').textContent=sel;
    qs('veText').value=(el.innerText||'').trim().slice(0,500);
    const cs=doc.defaultView.getComputedStyle(el); qs('veFontSize').value=parseInt(cs.fontSize)||''; qs('veColor').value=rgbToHex(cs.color)||'#241b25'; qs('veBg').value=rgbToHex(cs.backgroundColor)||'#ffffff';
    const pw=el.parentElement?.clientWidth||0; qs('veWidth').value=pw?Math.max(1,Math.min(100,Math.round((el.getBoundingClientRect().width/pw)*100))):''; qs('veHidden').checked=el.style.display==='none';
  },true);
  doc.addEventListener('mouseover',e=>{const el=e.target?.closest?.('*');if(el&&el!==doc.body)el.style.outline='2px dashed rgba(216,27,134,.35)';},true);
  doc.addEventListener('mouseout',e=>{const el=e.target?.closest?.('*');if(el&&el!==visualSelected)el.style.outline='';},true);
}
function applyVisualStateToFrame(){const doc=frameDoc();if(!doc)return;Object.entries(visualState.elements||{}).forEach(([sel,c])=>{try{const el=doc.querySelector(sel);if(!el)return;if(c.text!==undefined&&c.text!=='')el.innerText=c.text;if(c.styles)Object.assign(el.style,c.styles);if(c.hidden)el.style.display='none';else if(c.hidden===false)el.style.display='';}catch(e){}});let old=doc.getElementById('elora-dashboard-custom-css');if(old)old.remove();if(visualState.css){old=doc.createElement('style');old.id='elora-dashboard-custom-css';old.textContent=visualState.css;doc.head.appendChild(old)}(visualState.customSections||[]).forEach(sec=>{if(!doc.getElementById('elora-custom-section-'+sec.id)){const wrap=doc.createElement('section');wrap.id='elora-custom-section-'+sec.id;wrap.className='elora-dashboard-custom-section';wrap.style.cssText='padding:40px 20px;margin:20px 0;border-radius:24px;background:linear-gradient(135deg,#fff0f7,#f4e8ff);text-align:center';wrap.innerHTML=`<h2>${safeText(sec.title)}</h2><p>${safeText(sec.text||'')}</p>${sec.link?`<a href="${safeText(sec.link)}" style="display:inline-block;padding:10px 18px;border-radius:999px;background:#d81b86;color:#fff;text-decoration:none">اكتشفي الآن</a>`:''}`;doc.body.appendChild(wrap)}})}
function sitePreviewReload(){const f=qs('sitePreview');if(!f)return;const st=qs('previewLoadStatus');if(st){st.className='status pending';st.textContent='جاري فتح محرر الموقع...';}f.src='index.html?editorPreview='+Date.now();}
function setPreviewMode(mode,width=390){const w=qs('visualPreviewWrap')||qs('visual-preview-wrap');w.classList.toggle('mobile',mode==='mobile');w.classList.remove('preview-360','preview-390','preview-412');const label=qs('previewSizeLabel');if(mode==='mobile'){w.classList.add('preview-'+width);if(label)label.textContent='معاينة هاتف '+width+'px'}else{if(label)label.textContent='معاينة الكمبيوتر'}}
function applySelectedElement(){if(!visualSelected)return alert('اختاري عنصرًا من المعاينة أولًا');const sel=makeSelector(visualSelected),text=qs('veText').value;const c={text,styles:{}};if(qs('veFontSize').value)c.styles.fontSize=qs('veFontSize').value+'px';if(qs('veColor').value)c.styles.color=qs('veColor').value;if(qs('veBg').value)c.styles.backgroundColor=qs('veBg').value;if(qs('veWidth').value)c.styles.width=qs('veWidth').value+'%';c.hidden=qs('veHidden').checked;visualState.elements[sel]=c;applyVisualStateToFrame()}
function addVisualSection(){const title=qs('newSectionTitle').value.trim();if(!title)return alert('اكتبي عنوان القسم');visualState.customSections.push({id:Date.now(),title,text:qs('newSectionText').value.trim(),link:qs('newSectionLink').value.trim()});applyVisualStateToFrame();qs('newSectionTitle').value='';qs('newSectionText').value='';qs('newSectionLink').value=''}
async function saveVisualEditor(){if(!requirePermission('site.edit'))return;const sb=window.eloraSupabase;if(!sb)return alert('Supabase غير متصل');visualState.css=qs('veCss').value;const r=await sb.from('site_customizations').upsert({id:1,config:visualState,updated_at:new Date().toISOString()},{onConflict:'id'});if(r.error)return alert('تعذر حفظ تعديلات الموقع: '+r.error.message);alert('تم حفظ تعديلات الموقع بنجاح')}
async function resetVisualEditor(){if(!requirePermission('site.edit'))return;if(!confirm('استعادة إعدادات الموقع المحفوظة؟'))return;visualState={elements:{},customSections:[],css:''};qs('veCss').value='';applyVisualStateToFrame();const sb=window.eloraSupabase;if(sb)await sb.from('site_customizations').upsert({id:1,config:visualState,updated_at:new Date().toISOString()},{onConflict:'id'});}
const previewFrame=qs('sitePreview');if(previewFrame){previewFrame.addEventListener('load',async()=>{const st=qs('previewLoadStatus');if(st){st.className='status done';st.textContent='الموقع جاهز للتعديل — اضغطي على أي عنصر';}setTimeout(async()=>{await loadVisualState();bindFramePicker()},80)});previewFrame.addEventListener('error',()=>{const st=qs('previewLoadStatus');if(st){st.className='status cancel';st.textContent='تعذر تحميل المعاينة. أعيدي فتح المحرر.';}});}

async function grantPrimeByEmail(){if(!requirePermission('prime.manual_grant'))return;const email=qs('primeGrantEmail').value.trim();const days=Math.max(1,parseInt(qs('primeGrantDays').value||30,10));const out=qs('primeGrantResult');if(!email){out.className='bulk-result err';out.textContent='اكتبي البريد الإلكتروني.';return}const sb=window.eloraSupabase;if(!sb){out.textContent='Supabase غير متصل.';return}out.className='bulk-result';out.textContent='جاري التفعيل...';try{const r=await sb.rpc('admin_grant_prime_by_email',{p_email:email,p_days:days});if(r.error)throw r.error;out.className='bulk-result ok';out.textContent='تم تفعيل Elora Prime للعميل بنجاح.'}catch(e){out.className='bulk-result err';out.textContent='تعذر التفعيل: '+(e.message||'تأكدي أن البريد مسجل وأن حسابك إداري.')}}
function normalizeArabicHeader(v){return String(v??'').trim().toLowerCase().replace(/[\u200e\u200f]/g,'')}
function getRowValueV2(row, keys){for(const k of keys){if(row[k]!==undefined&&row[k]!==null&&String(row[k]).trim()!=='')return row[k]}return ''}
function splitOptional(v){return String(v??'').split(/[,،|\\/]+/).map(x=>x.trim()).filter(Boolean)}
const ELORA_SITE_CATEGORIES=['لانجري','اكسسوارات','ساعات حريمي','ساعات رجالي','شنط حريمي','شنط مدارس','مكياج'];
function productCategoryNames(){
  const db=Array.isArray(categories)?categories.map(c=>String(c.name||'').trim()).filter(Boolean):[];
  return [...new Set([...ELORA_SITE_CATEGORIES,...db])];
}
function populateProductCategoryControls(){
  const names=productCategoryNames();
  const select=qs('peCategory');
  if(select){const current=select.value;select.innerHTML='<option value="">اختاري القسم</option>'+names.map(n=>`<option value="${escDash(n)}">${escDash(n)}</option>`).join('');if(current)select.value=current;}
  const filter=qs('productCategoryFilter');
  if(filter){const current=filter.value;filter.innerHTML='<option value="">كل الأقسام</option>'+names.map(n=>`<option value="${escDash(n)}">${escDash(n)}</option>`).join('');if(current)filter.value=current;}
  const bulk=qs('bulkCategoryOverride');
  if(bulk){const current=bulk.value;bulk.innerHTML='<option value="">استخدم قسم كل صف في Excel</option>'+names.map(n=>`<option value="${escDash(n)}">${escDash(n)}</option>`).join('');if(current)bulk.value=current;}
}
let editingProductId=null;
function openProductEditor(product=null){
  if(!requirePermission(product?'products.edit':'products.add')) return;
  editingProductId=product?.id||null;
  qs('productEditor').hidden=false;
  qs('productEditorTitle').textContent=product?'تعديل المنتج':'إضافة منتج';
  qs('productEditorResult').textContent='';
  ['peCode','peName','peCategory','pePrice','peOldPrice','peWholesale','peStock','peImage','peDescription','peSizes','peVariants','peSku','peWeight','peDiscount'].forEach(id=>{const e=qs(id);if(e)e.value='';});
  qs('peStock').value='0'; qs('peDiscount').value='0'; qs('peWeight').value=''; qs('peSku').value=''; qs('peActive').value='true'; qs('peFeatured').checked=false; qs('colorRows').innerHTML=''; if(qs('peImagePreview'))qs('peImagePreview').innerHTML=''; if(qs('peImageFile'))qs('peImageFile').value='';
  if(product){
    qs('peCode').value=product.code||product.product_code||''; qs('peName').value=product.name||''; qs('peCategory').value=product.category||product.section||'';
    qs('pePrice').value=product.price??''; qs('peOldPrice').value=product.old_price??''; qs('peWholesale').value=product.wholesale_price??''; qs('peStock').value=product.stock??0; qs('peImage').value=product.image||''; setImagePreview('peImagePreview',product.image); qs('peDescription').value=product.description||''; qs('peSku').value=product.sku||''; qs('peWeight').value=product.weight??''; qs('peDiscount').value=product.discount??0; qs('peActive').value=String(product.active!==false); qs('peFeatured').checked=!!product.featured;
    const sizes=Array.isArray(product.sizes)?product.sizes:[]; qs('peSizes').value=sizes.join('\n');
    qs('peVariants').value=product.variants?.length?JSON.stringify(product.variants,null,2):'';
    const cols=Array.isArray(product.color_options)&&product.color_options.length?product.color_options:(Array.isArray(product.colors)?product.colors.map(x=>({name:String(x),hex:'#d946ef'})):[]);
    cols.forEach(c=>addColorRow(c));
  } else addColorRow();
  applyAccess(window.currentStaffPermissions||{});
  qs('productEditor').scrollIntoView({behavior:'smooth',block:'start'});
}
function closeProductEditor(){editingProductId=null;if(qs('productEditor'))qs('productEditor').hidden=true;}
function addColorRow(c={name:'',hex:'#d946ef'}){const wrap=qs('colorRows');if(!wrap)return;const row=document.createElement('div');row.className='color-row';row.innerHTML=`<input class="color-picker" type="color" value="${escDash(c.hex||'#d946ef')}" oninput="this.nextElementSibling.style.background=this.value;this.parentElement.querySelector('.color-hex').value=this.value"><span class="color-preview" style="background:${escDash(c.hex||'#d946ef')}"></span><input class="color-name" placeholder="اسم اللون (اختياري)" value="${escDash(c.name||'')}"><input class="color-hex" placeholder="#RRGGBB" value="${escDash(c.hex||'#d946ef')}" maxlength="7" oninput="const v=this.value;this.parentElement.querySelector('.color-picker').value=/^#[0-9a-fA-F]{6}$/.test(v)?v:'#d946ef';this.parentElement.querySelector('.color-preview').style.background=v"><button type="button" class="btn light remove-color" onclick="this.parentElement.remove()">حذف</button>`;wrap.appendChild(row);}
function parseEditorColors(){return [...document.querySelectorAll('#colorRows .color-row')].map(r=>({name:r.querySelector('.color-name')?.value.trim()||'',hex:(r.querySelector('.color-hex')?.value.trim()||r.querySelector('.color-picker')?.value||'#d946ef').toUpperCase()})).filter(c=>/^#[0-9A-F]{6}$/.test(c.hex));}
function parseFreeSizes(v){return String(v||'').split(/[\n,،]+/).map(x=>x.trim()).filter(Boolean);}
async function saveProductEditor(){
  const sb=window.eloraSupabase;if(!sb)return;
  if(!requirePermission(editingProductId?'products.edit':'products.add'))return;
  const name=qs('peName').value.trim();if(!name){qs('productEditorResult').className='bulk-result err';qs('productEditorResult').textContent='اكتبي اسم المنتج أولاً.';return;}
  let variants=[];const raw=qs('peVariants').value.trim();if(raw){try{variants=JSON.parse(raw);if(!Array.isArray(variants))throw new Error('المتغيرات يجب أن تكون Array');}catch(e){qs('productEditorResult').className='bulk-result err';qs('productEditorResult').textContent='صيغة المتغيرات غير صحيحة.';return;}}
  const color_options=parseEditorColors(), sizes=parseFreeSizes(qs('peSizes').value);
  let image=qs('peImage').value.trim()||null;const imageFile=qs('peImageFile')?.files?.[0];if(imageFile){try{image=await uploadImageToSupabase(imageFile,'products')}catch(e){qs('productEditorResult').className='bulk-result err';qs('productEditorResult').textContent='تعذر رفع الصورة: '+(e.message||'خطأ غير معروف');return}}const row={name,description:qs('peDescription').value.trim()||null,category:qs('peCategory').value.trim()||null,price:Number(qs('pePrice').value||0),old_price:Number(qs('peOldPrice').value||0)||null,wholesale_price:Number(qs('peWholesale').value||0)||null,stock:parseInt(qs('peStock').value||0,10)||0,image,code:qs('peCode').value.trim()||null,colors:color_options.map(c=>c.name||c.hex),color_options,sizes,variants,sku:qs('peSku').value.trim()||null,weight:qs('peWeight').value?Number(qs('peWeight').value):null,discount:Number(qs('peDiscount').value||0),featured:!!qs('peFeatured').checked,active:qs('peActive').value==='true'};
  if(editingProductId)row.id=editingProductId;
  qs('saveProductBtn').disabled=true;try{const r=await sb.from('products').upsert(row,{onConflict:'id'});if(r.error)throw r.error;qs('productEditorResult').className='bulk-result ok';qs('productEditorResult').textContent='تم حفظ المنتج بنجاح.';await loadData();setTimeout(closeProductEditor,500);}catch(e){qs('productEditorResult').className='bulk-result err';qs('productEditorResult').textContent='تعذر حفظ المنتج: '+(e.message||'خطأ غير معروف');}finally{qs('saveProductBtn').disabled=false;}
}

function normalizeProductRowV2(r){const colors=splitOptional(getRowValueV2(r,['الألوان','الالوان','ألوان','الوان','colors','color']));const sizes=splitOptional(getRowValueV2(r,['المقاسات','المقاس','مقاسات','sizes','size']));const variantsRaw=getRowValueV2(r,['الخيارات','المتغيرات','variants']);let color_options=[];const colorHexRaw=getRowValueV2(r,['ألوان HEX','color_options','color_hex']);if(colorHexRaw){try{const parsed=typeof colorHexRaw==='string'?JSON.parse(colorHexRaw):colorHexRaw;if(Array.isArray(parsed))color_options=parsed;}catch(e){}}if(!color_options.length)color_options=colors.map(c=>({name:c,hex:'#D946EF'}));return {name:String(getRowValueV2(r,['اسم المنتج','الاسم','name','product_name'])).trim(),description:String(getRowValueV2(r,['الوصف','وصف','description'])).trim()||null,category:String(getRowValueV2(r,['الصنف','القسم','category','section'])).trim()||null,price:Number(getRowValueV2(r,['سعر البيع','السعر','price','sale_price'])||0),old_price:Number(getRowValueV2(r,['السعر القديم','old_price','oldPrice'])||0)||null,wholesale_price:Number(getRowValueV2(r,['سعر الجملة','wholesale_price','wholesalePrice'])||0)||null,code:String(getRowValueV2(r,['كود المنتج','الكود','code','product_code'])).trim()||null,stock:parseInt(getRowValueV2(r,['المخزون','الكمية','stock','inventory'])||0,10)||0,discount:Number(getRowValueV2(r,['الخصم','discount'])||0)||0,featured:['1','true','yes','نعم','مميز'].includes(String(getRowValueV2(r,['مميز','featured'])).toLowerCase()),active:!['0','false','no','لا','غير فعال'].includes(String(getRowValueV2(r,['نشط','فعال','active'])).toLowerCase()),image:String(getRowValueV2(r,['الصورة','رابط الصورة','image','image_url'])).trim()||null,colors:colors.length?colors:null,sizes:sizes.length?sizes:null,variants:variantsRaw?variantsRaw:null,color_options:color_options.length?color_options:null}}
async function previewBulkImportV2(){const input=qs('bulkProductsFile'),preview=qs('bulkPreview'),btn=qs('bulkImportBtn');if(!input?.files?.[0]){preview.textContent='لم يتم اختيار ملف بعد.';btn.disabled=true;return}try{const data=await input.files[0].arrayBuffer();const wb=XLSX.read(data,{type:'array'});const ws=wb.Sheets[wb.SheetNames[0]];const rows=XLSX.utils.sheet_to_json(ws,{defval:''});bulkRows=rows.map(normalizeProductRowV2).filter(r=>r.name||r.code);const override=qs('bulkCategoryOverride')?.value.trim();if(override)bulkRows=bulkRows.map(r=>({...r,category:override}));preview.innerHTML=`تم العثور على <b>${bulkRows.length.toLocaleString('ar-EG')}</b> منتج. الألوان والمقاسات اختيارية، ويمكن تركها فارغة.`;btn.disabled=!bulkRows.length}catch(e){preview.textContent='تعذر قراءة الملف: '+e.message;btn.disabled=true}}
async function runBulkImportV2(){if(!requirePermission('products.import'))return;const sb=window.eloraSupabase,btn=qs('bulkImportBtn'),result=qs('bulkResult');if(!sb||!bulkRows.length)return;btn.disabled=true;let ok=0;try{for(let i=0;i<bulkRows.length;i+=250){const batch=bulkRows.slice(i,i+250);let r=await sb.from('products').upsert(batch,{onConflict:'code',ignoreDuplicates:false});if(r.error)throw r.error;ok+=batch.length;const pct=Math.round(ok/bulkRows.length*100);qs('bulkProgress').hidden=false;qs('bulkProgressBar').style.width=pct+'%';qs('bulkProgressText').textContent=pct+'%'}result.className='bulk-result ok';result.textContent=`تم استيراد ${ok.toLocaleString('ar-EG')} منتج بنجاح.`;await loadData()}catch(e){result.className='bulk-result err';result.textContent=`توقف الاستيراد بعد ${ok.toLocaleString('ar-EG')} منتج: ${e.message}`}finally{btn.disabled=false}}
function downloadArabicTemplate(){const rows=[{'كود المنتج':'EL001','اسم المنتج':'اسم المنتج','الوصف':'وصف اختياري','الصنف':'إكسسوارات','سعر البيع':250,'السعر القديم':300,'سعر الجملة':150,'المخزون':20,'الخصم':0,'مميز':'نعم','نشط':'نعم','الألوان':'أسود، أبيض','ألوان HEX':'[{"name":"أسود","hex":"#000000"},{"name":"أبيض","hex":"#FFFFFF"}]','المقاسات':'Oversize، Free Size، S، M، L','الخيارات':'','الصورة':'EL001.jpg'}];const ws=XLSX.utils.json_to_sheet(rows);const cats=ELORA_SITE_CATEGORIES.map((name,i)=>({الترتيب:i+1,'اسم القسم':name}));const wc=XLSX.utils.json_to_sheet(cats);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'المنتجات');XLSX.utils.book_append_sheet(wb,wc,'الأقسام المعتمدة');XLSX.writeFile(wb,'نموذج_منتجات_Elora_بالعربي.xlsx')}

