package com.elora.dashboard;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_NOTIFICATIONS = 901;
    private static final String CHANNEL_ID = "elora_orders";
    private WebView webView;
    private String cachedPushToken = "";

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        initFirebaseFromAsset();
        webView = new WebView(this);
        setContentView(webView);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidDashboard");
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                String u=request.getUrl().toString();
                return !u.startsWith("https://appassets.androidplatform.net/");
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/Elora_Dashboard.html");
    }

    private void initFirebaseFromAsset(){
        try {
            if (!FirebaseApp.getApps(this).isEmpty()) return;
            InputStream is=getAssets().open("firebase-config.json");
            byte[] b=new byte[is.available()]; int n=is.read(b); is.close();
            JSONObject root=new JSONObject(new String(b,0,n,StandardCharsets.UTF_8));
            JSONObject pi=root.getJSONObject("project_info");
            JSONObject c=root.getJSONArray("client").getJSONObject(0);
            String appId=c.getJSONObject("client_info").getString("mobilesdk_app_id");
            String key=c.getJSONArray("api_key").getJSONObject(0).getString("current_key");
            FirebaseOptions o=new FirebaseOptions.Builder().setProjectId(pi.getString("project_id"))
                    .setApplicationId(appId).setApiKey(key).setGcmSenderId(pi.getString("project_number")).build();
            FirebaseApp.initializeApp(this,o);
            FirebaseMessaging.getInstance().setAutoInitEnabled(true);
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (t.isSuccessful() && t.getResult() != null) {
                    cachedPushToken = t.getResult();
                    getSharedPreferences("elora_push", MODE_PRIVATE).edit()
                            .putString("token", cachedPushToken).apply();
                }
            });
        } catch(Exception ignored) {}
    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"طلبات Elora",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("إشعارات الطلبات الجديدة");
            ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private void requestNotifications(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);
    }

    private void showOrder(String title,String body,String orderNumber){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
        Intent i=new Intent(this,MainActivity.class); i.putExtra("order_number",orderNumber);
        PendingIntent pi=PendingIntent.getActivity(this,orderNumber.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,CHANNEL_ID).setSmallIcon(com.elora.dashboard.R.drawable.ic_stat_elora)
                .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(orderNumber.hashCode(),b.build());
    }

    private void pushToken(String callback){
        if(FirebaseApp.getApps(this).isEmpty()){
            sendJs("eloraPushTokenError", "Firebase غير مهيأ");
            return;
        }
        String saved=getSharedPreferences("elora_push", MODE_PRIVATE).getString("token", "");
        if(!saved.isEmpty()) cachedPushToken=saved;
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{
            if(t.isSuccessful() && t.getResult()!=null){
                cachedPushToken=t.getResult();
                getSharedPreferences("elora_push", MODE_PRIVATE).edit().putString("token",cachedPushToken).apply();
                if(webView!=null) webView.post(()->webView.evaluateJavascript("window."+callback+"("+JSONObject.quote(cachedPushToken)+")",null));
            }else{
                String msg=t.getException()!=null?t.getException().getMessage():"تعذر الحصول على FCM Token";
                sendJs("eloraPushTokenError", msg);
            }
        });
    }

    private void sendJs(String fn,String value){
        if(webView==null)return;
        webView.post(()->webView.evaluateJavascript("window."+fn+"("+JSONObject.quote(value)+")",null));
    }

    public class AndroidBridge {
        @JavascriptInterface public void requestNotificationPermission(){runOnUiThread(MainActivity.this::requestNotifications);}
        @JavascriptInterface public void showOrderNotification(String title,String body,String number){runOnUiThread(()->showOrder(title,body,number));}
        @JavascriptInterface public void registerPushToken(String callback){pushToken(callback);}
        @JavascriptInterface public boolean isPushConfigured(){return !FirebaseApp.getApps(MainActivity.this).isEmpty();}
        @JavascriptInterface public String getPushDiagnostics(){
            boolean firebase=!FirebaseApp.getApps(MainActivity.this).isEmpty();
            String saved=getSharedPreferences("elora_push", MODE_PRIVATE).getString("token", "");
            return "firebase="+firebase+";token="+(saved.isEmpty()?"missing":"ready");
        }
        @JavascriptInterface public void goBack(){runOnUiThread(()->{if(webView!=null) webView.evaluateJavascript("window.dashboardGoBack&&window.dashboardGoBack()",null);});}
    }

    @Override public void onBackPressed(){
        if(webView!=null){webView.evaluateJavascript("(window.dashboardGoBack&&window.dashboardGoBack())",v->{});return;}
        super.onBackPressed();
    }
}
