begin;

-- Elora payment controls + Prime monthly shipping allowance.
alter table public.store_settings add column if not exists payment_instapay boolean not null default true;
alter table public.store_settings add column if not exists payment_fawry boolean not null default true;
alter table public.store_settings add column if not exists paymob_create_payment_url text;
alter table public.store_settings add column if not exists prime_free_shipping_orders integer not null default 5;
update public.store_settings set prime_free_shipping_orders=5 where prime_free_shipping_orders is null or prime_free_shipping_orders=6;

commit;
