# Elora Dashboard — Professional Premium

نسخة مطوّرة من نفس مشروع Elora Dashboard، مع الحفاظ على أصول الموقع الحالية دون تعديل `index.html`.

## المزايا الرئيسية
- Dark Mode احترافي مع حفظ الاختيار، دعم تفضيل النظام، وتحديث لون شريط النظام.
- واجهة Premium متجاوبة للهاتف والكمبيوتر مع منع الحركة الأفقية المزعجة.
- قائمة هاتفية Drawer احترافية مع خلفية وإغلاق تلقائي.
- مركز تحكم سريع للخدمات الأساسية.
- إدارة الطلبات: بحث، فلترة، تفاصيل، حالات، وحذف حسب الصلاحية، مع عرض مختصر على الهاتف.
- تقارير وأرباح: المبيعات، تكلفة الجملة، الربح، متوسط الطلب، التسليم، الإلغاء، ورسم مبيعات لآخر 7 أيام.
- إدارة المنتجات: إضافة/تعديل/حذف، المخزون، الأسعار، سعر الجملة، الخصم، المنتج المميز، التفعيل، SKU، الوزن، الألوان، المقاسات والمتغيرات.
- استيراد وتصدير Excel/CSV ورفع صور دفعة واحدة مع ضغط WebP عند توفر R2.
- الأقسام والعروض والبنرات.
- أكواد الخصم مع دعم إعداد **أول طلب فقط**.
- العملاء وElora Prime والشحن وطرق الدفع وإعدادات المتجر.
- موظفون وصلاحيات granular مع تحديث فوري.
- محرر الموقع البصري موجود كميزة داخل لوحة التحكم، بينما ملف الموقع نفسه لم يتم تعديله في هذه النسخة.

## قاعدة البيانات
شغّل مرة واحدة: `Elora_Dashboard_Full_Fix_Migration.sql`
ثم شغّل: `Elora_Dashboard_Professional_Upgrade.sql` لإضافة دعم first-order-only للكوبونات والـvalidator الآمن المخصص للعميل.

> ملاحظة: تفعيل قاعدة first-order-only على checkout الفعلي يحتاج أن يستدعي checkout دالة التحقق المخصصة؛ هذه النسخة لا تغيّر `index.html` تنفيذًا لطلبك.

## البناء
ارفع **محتويات المشروع** إلى GitHub، ثم شغّل:
`.github/workflows/build-apk.yml`

الـWorkflow يستخدم Java 17 وGradle 8.7 مع تعطيل Gradle cache لتجنب أخطاء cache قبل التحقق من بنية المشروع.


## Shipping + Visual Editor Fix
- Added all 27 Egyptian governorates with editable default shipping price.
- Added center selection toggle per governorate; when disabled, governorate price applies to the whole governorate.
- Seeded governorate centers/areas and editable center prices.
- Repaired visual editor picker/save/load flow and added RLS policies for site_customizations.
- Customer checkout reads the shipping configuration without changing the existing visual design.
