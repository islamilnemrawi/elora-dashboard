# Elora Dashboard

Android wrapper for the existing Elora Dashboard web application.

## GitHub APK build

1. Upload this whole folder to a GitHub repository.
2. Open **Actions**.
3. Choose **Build Elora Dashboard APK**.
4. Press **Run workflow**.
5. After the build finishes, download the **Elora-Dashboard-APK** artifact.

The dashboard UI is kept in `app/src/main/assets/Elora_Dashboard.html` and the Supabase configuration is in `app/src/main/assets/supabase-config.js`.
